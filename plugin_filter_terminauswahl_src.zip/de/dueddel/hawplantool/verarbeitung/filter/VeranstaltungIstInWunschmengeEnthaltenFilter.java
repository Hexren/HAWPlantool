package de.dueddel.hawplantool.verarbeitung.filter;

import com.jgoodies.forms.layout.CellConstraints;
import com.jgoodies.forms.layout.FormLayout;
import de.dueddel.hawplantool.HAWPlanToolException;
import de.dueddel.hawplantool.fabrik.SwingFabrik;
import de.dueddel.hawplantool.verarbeitung.daten.VeranstaltungsTermin;
import de.dueddel.hawplantool.verarbeitung.input.VeranstaltungsTerminErmittler;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;

/**
 * <code>VeranstaltungIstInWunschmengeEnthaltenFilter</code>
 */
public class VeranstaltungIstInWunschmengeEnthaltenFilter extends VeranstaltungsTerminFilter_A implements ActionListener {

	private Collection<String> namenDerVeranstaltungen;

	private JLabel labelAuswahlMoeglichkeiten;
	private JLabel labelAuswahl;
	private JScrollPane scrollPaneAuswahlmoeglichkeiten;
	private JScrollPane scrollPaneAuswahl;
	private JList listeAuswahlmoeglichkeiten;
	private JList listeAuswahl;
	private JButton buttonAktuellenRein;
	private JButton buttonAktuellenRaus;
	private JButton buttonAlleRein;
	private JButton buttonAlleRaus;
	private DefaultListModel listModelAuswahlmoeglichkeiten;
	private DefaultListModel listModelAuswahl;

	private Object[] backupListeAuswahl;
	private Object[] backupListeAuswahlmoeglichkeiten;
	private VeranstaltungsTerminErmittler backupTerminErmittler;

	/**
	 * Konstruktor. Erzeugt eine Instanz der Klasse <code>VeranstaltungIstInWunschmengeEnthaltenFilter</code>.
	 */
	public VeranstaltungIstInWunschmengeEnthaltenFilter() {
		namenDerVeranstaltungen = new ArrayList<String>();

		labelAuswahlMoeglichkeiten = new JLabel("Veranstaltungen");
		labelAuswahl = new JLabel("Auswahl");

		listModelAuswahlmoeglichkeiten = new DefaultListModel();
		listModelAuswahl = new DefaultListModel();

		listeAuswahlmoeglichkeiten = new JList();
		listeAuswahlmoeglichkeiten.setModel(listModelAuswahlmoeglichkeiten);
		listeAuswahlmoeglichkeiten.setLayoutOrientation(JList.VERTICAL);
		listeAuswahl = new JList();
		listeAuswahl.setModel(listModelAuswahl);
		listeAuswahl.setLayoutOrientation(JList.VERTICAL);

		scrollPaneAuswahlmoeglichkeiten = new JScrollPane(listeAuswahlmoeglichkeiten);
		scrollPaneAuswahl = new JScrollPane(listeAuswahl);

		buttonAktuellenRein = SwingFabrik.erzeugeButton(">", this);
		buttonAktuellenRaus = SwingFabrik.erzeugeButton("<", this);
		buttonAlleRein = SwingFabrik.erzeugeButton(">>", this);
		buttonAlleRaus = SwingFabrik.erzeugeButton("<<", this);
	}

	public boolean isZuFiltern(VeranstaltungsTermin termin) throws HAWPlanToolException {
		return !namenDerVeranstaltungen.contains(getName(termin));
	}

	public void setAktuellenTerminErmittlerFuerKonfiguration(VeranstaltungsTerminErmittler terminErmittler) throws HAWPlanToolException {
//		wenn noch nicht initialisiert oder anderer VeranstaltungsTerminErmittler �bergeben als beim letzten Mal
		if (backupListeAuswahlmoeglichkeiten == null || backupTerminErmittler == null || backupTerminErmittler != terminErmittler) {
			backupTerminErmittler = terminErmittler;

//			Termine aller Veranstaltungen ermitteln
			Collection<VeranstaltungsTermin> veranstaltungsTermine = null;
			try {
				veranstaltungsTermine = terminErmittler.getVeranstaltungsTermineUngefiltert();
			} catch (HAWPlanToolException e) {
				throw new HAWPlanToolException("Fehler beim Ermitteln der Termine aus der Quelle '" + terminErmittler + "'.", e);
			}
			Collection<String> namenVeranstaltungen = new ArrayList<String>();

//			Namen der Veranstaltungen ermitteln
			if (veranstaltungsTermine != null) {
				for (VeranstaltungsTermin veranstaltungsTermin : veranstaltungsTermine) {
					String nameVeranstaltung = getName(veranstaltungsTermin);

					if (!namenVeranstaltungen.contains(nameVeranstaltung)) {
						namenVeranstaltungen.add(nameVeranstaltung);
					}
				}
			}

//			Auswahl und Auswahlm�glichkeiten initialisieren
			backupListeAuswahl = new Object[0];
			backupListeAuswahlmoeglichkeiten = new Object[namenVeranstaltungen.size()];
			Iterator<String> namenVeranstaltungenIt = namenVeranstaltungen.iterator();

			for (int i = 0; namenVeranstaltungenIt.hasNext(); i++) {
				backupListeAuswahlmoeglichkeiten[i] = namenVeranstaltungenIt.next();
			}
		}
	}

	private String getName(VeranstaltungsTermin termin) {
		return termin.getName() + "  [" + termin.getSemestergruppe() + "]";
	}

	public String getKurzbeschreibung() {
		return "Veranstaltungen werden explizit ausgew�hlt";
	}

	public String getBeschreibung() {
		return "Filtert alle Veranstaltungen heraus, die nicht explizit �ber den Einstellungs-Dialog ausgew�hlt werden.";
	}

	protected void initialisierePanelFuerEinstellungen(JPanel panel) {
//		Layout festlegen
		String spalten = "150dlu:grow, 8dlu:grow(0.5), pref:grow, 8dlu:grow(0.5), 150dlu:grow";
		String zeilen = "pref:grow, 4dlu:grow(0.5), pref:grow, 4dlu:grow(0.5), pref:grow, 4dlu:grow(0.5), pref:grow, 4dlu:grow(0.5), pref:grow, 150dlu:grow(0.5)";
		FormLayout formLayout = new FormLayout(spalten, zeilen);
		panel.setLayout(formLayout);

//		Komponenten anordnen
		CellConstraints cc = new CellConstraints();
		panel.add(labelAuswahlMoeglichkeiten, cc.xy(1, 1));
		panel.add(labelAuswahl, cc.xy(5, 1));
		panel.add(scrollPaneAuswahlmoeglichkeiten, cc.xywh(1, 3, 1, 8));
		panel.add(scrollPaneAuswahl, cc.xywh(5, 3, 1, 8));
		panel.add(buttonAktuellenRein, cc.xy(3, 3));
		panel.add(buttonAktuellenRaus, cc.xy(3, 5));
		panel.add(buttonAlleRein, cc.xy(3, 7));
		panel.add(buttonAlleRaus, cc.xy(3, 9));

//		Listen mit Werten bef�llen
		listModelAuswahlmoeglichkeiten.removeAllElements();
		listModelAuswahl.removeAllElements();
		befuelleListe(listModelAuswahlmoeglichkeiten, backupListeAuswahlmoeglichkeiten);
		if (backupListeAuswahl != null) {
			befuelleListe(listModelAuswahl, backupListeAuswahl);
		}
	}

	public void aktionBeiKonfigurationOk() {
		backupListeAuswahlmoeglichkeiten = listModelAuswahlmoeglichkeiten.toArray();
		backupListeAuswahl = listModelAuswahl.toArray();

		namenDerVeranstaltungen = getAuswahlCollection();
	}

	public void aktionBeiKonfigurationAbbruch() {
	}

	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == buttonAktuellenRein) {
			Object[] selektierteObjekte = listeAuswahlmoeglichkeiten.getSelectedValues();
			befuelleListe(listModelAuswahl, selektierteObjekte);
			entferneWerteAusListe(listModelAuswahlmoeglichkeiten, selektierteObjekte);
		} else if (e.getSource() == buttonAktuellenRaus) {
			Object[] selektierteObjekte = listeAuswahl.getSelectedValues();
			befuelleListe(listModelAuswahlmoeglichkeiten, selektierteObjekte);
			entferneWerteAusListe(listModelAuswahl, selektierteObjekte);
		} else if (e.getSource() == buttonAlleRein) {
			befuelleListe(listModelAuswahl, listModelAuswahlmoeglichkeiten);
			listModelAuswahlmoeglichkeiten.removeAllElements();
		} else if (e.getSource() == buttonAlleRaus) {
			befuelleListe(listModelAuswahlmoeglichkeiten, listModelAuswahl);
			listModelAuswahl.removeAllElements();
		}
	}

	private void befuelleListe(DefaultListModel liste, DefaultListModel neueWerte) {
		befuelleListe(liste, neueWerte.toArray());
	}

	private void befuelleListe(DefaultListModel liste, Object[] neueWerte) {
		Object[] dieAltenWerte = liste.toArray();
		String[] dasNeueArray = new String[dieAltenWerte.length + neueWerte.length];

		for (int i = 0; i < dieAltenWerte.length; i++) {
			dasNeueArray[i] = (String) dieAltenWerte[i];
		}
		for (int i = 0; i < neueWerte.length; i++) {
			dasNeueArray[dieAltenWerte.length + i] = (String) neueWerte[i];
		}
		Arrays.sort(dasNeueArray);

		liste.removeAllElements();
		for (int i = 0; i < dasNeueArray.length; i++) {
			liste.addElement(dasNeueArray[i]);
		}
	}

	private void entferneWerteAusListe(DefaultListModel liste, Object[] zuEntfernendeWerte) {
		for (int i = 0; i < zuEntfernendeWerte.length; i++) {
			liste.removeElement(zuEntfernendeWerte[i]);
		}
	}

	private Collection<String> getAuswahlCollection() {
		Collection<String> auswahl = new ArrayList<String>();
		Object[] auswahlObjectArray = listModelAuswahl.toArray();

		for (int i = 0; i < auswahlObjectArray.length; i++) {
			auswahl.add((String) auswahlObjectArray[i]);
		}

		return auswahl;
	}
}