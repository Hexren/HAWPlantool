package de.dueddel.hawplantool.verarbeitung.output;

import de.dueddel.hawplantool.verarbeitung.VerarbeitungsObjekt_A;

/**
 * <code>ErgebnisErzeuger_A</code>
 */
public abstract class ErgebnisErzeuger_A extends VerarbeitungsObjekt_A implements ErgebnisErzeuger {

}