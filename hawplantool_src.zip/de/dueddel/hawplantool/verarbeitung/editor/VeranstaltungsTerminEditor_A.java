package de.dueddel.hawplantool.verarbeitung.editor;

import de.dueddel.hawplantool.verarbeitung.VerarbeitungsObjekt_A;

/**
 * <code>VeranstaltungsTerminEditor_A</code>
 */
public abstract class VeranstaltungsTerminEditor_A extends VerarbeitungsObjekt_A implements VeranstaltungsTerminEditor {

}