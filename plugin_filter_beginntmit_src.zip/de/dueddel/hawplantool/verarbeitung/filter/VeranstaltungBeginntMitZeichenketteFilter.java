package de.dueddel.hawplantool.verarbeitung.filter;

import de.dueddel.hawplantool.HAWPlanToolException;
import de.dueddel.hawplantool.verarbeitung.daten.VeranstaltungsTermin;

import javax.swing.*;

/**
 * <code>VeranstaltungBeginntMitZeichenketteFilter</code> filtert alle Veranstaltungen heraus, deren Bezeichnungen nicht mit der eingegebenen Zeichenkette beginnen.
 */
public class VeranstaltungBeginntMitZeichenketteFilter extends VeranstaltungsTerminFilter_A {

	private String zeichenkette;
	private JLabel label;
	private JTextField textfeld;

	/**
	 * Konstruktor. Erzeugt eine Instanz der Klasse <code>VeranstaltungBeginntMitZeichenketteFilter</code>.
	 */
	public VeranstaltungBeginntMitZeichenketteFilter() {
		label = new JLabel("Zeichenkette");
		textfeld = new JTextField();
		textfeld.setColumns(10);
		textfeld.setText(zeichenkette);
	}

	public boolean isZuFiltern(VeranstaltungsTermin termin) throws HAWPlanToolException {
		try {
			return !termin.getName().startsWith(zeichenkette);
		} catch (Exception e) {
			throw new HAWPlanToolException("Fehler beim Filtern des Termins [" + termin.toString() + "] mit der Zeichenkette '" + zeichenkette + "'.");
		}
	}

	public String getKurzbeschreibung() {
		return "Namen der Veranstaltungen beginnen mit '" + zeichenkette + "'";
	}

	public String getBeschreibung() {
		return "Filtert alle Veranstaltungen heraus, deren Namen nicht mit der eingegebenen Zeichenkette '" + (textfeld.getText() != null ? textfeld.getText() : zeichenkette) + "' beginnen." +
				"\n\nDas kann zum Beispiel dann n�tzlich sein, wenn alle Wahlpflichtkurse der Informatik ermittelt werden sollen. Die einzugebene Zeichenkette w�re dann beispielsweise 'INF-WP'.";
	}

	protected void initialisierePanelFuerEinstellungen(JPanel panel) {
		textfeld.setSelectionStart(0);
		if (zeichenkette != null) {
			textfeld.setSelectionEnd(zeichenkette.length());
		}

		panel.add(label);
		panel.add(textfeld);
	}

	public void aktionBeiKonfigurationOk() {
		zeichenkette = textfeld.getText();
	}

	public void aktionBeiKonfigurationAbbruch() {
		textfeld.setText(zeichenkette);
	}
}