package de.dueddel.hawplantool.verarbeitung.output;

import com.jgoodies.forms.factories.Borders;
import com.jgoodies.forms.factories.ButtonBarFactory;
import com.jgoodies.forms.layout.CellConstraints;
import com.jgoodies.forms.layout.FormLayout;
import de.dueddel.hawplantool.fabrik.SwingFabrik;
import de.dueddel.hawplantool.gui.Dialog;
import de.dueddel.hawplantool.util.DatumUtil;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Date;

/**
 * <code>ViertelDialog</code>
 */
public class ViertelDialog extends Dialog implements ActionListener {

	private JButton buttonOk;
	private JButton buttonAbbruch;
	private JSpinner[] spinnerUhrzeitenViertel;
	private JSpinner spinnerDauerViertel;

	private int[][] uhrzeitenViertel;

	/**
	 * Konstruktor. Erzeugt eine Instanz der Klasse <code>ViertelDialog</code>.
	 */
	public ViertelDialog(JFrame owner, int[][] uhrzeitenViertel) {
		super(owner, "Zeiten der Veranstaltungsviertel");
		this.uhrzeitenViertel = uhrzeitenViertel;
		initDialog();
		zeigeDialog();
	}

	private void initDialog() {
//		Komponenten initialisieren
		buttonOk = SwingFabrik.erzeugeButton("Ok", 'o', this);
		buttonAbbruch = SwingFabrik.erzeugeButton("Abbruch", 'a', this);

		JPanel dialogPanel = new JPanel();
		JPanel einstellungenPanel = getEinstellungenPanel();
		JPanel buttonPanel = ButtonBarFactory.buildOKCancelBar(buttonOk, buttonAbbruch);

//		Layout festlegen
		String spalten = "pref:grow";
		String zeilen = "fill:pref:grow, 4dlu, pref";
		FormLayout formLayout = new FormLayout(spalten, zeilen);
		dialogPanel.setLayout(formLayout);
		dialogPanel.setBorder(Borders.DIALOG_BORDER);

//		Komponenten anordnen
		CellConstraints cc = new CellConstraints();
		dialogPanel.add(einstellungenPanel, cc.xy(1, 1));
		dialogPanel.add(buttonPanel, cc.xy(1, 3));

		getContentPane().add(dialogPanel);
		getRootPane().setDefaultButton(buttonOk);
		setResizable(true);
	}

	private JPanel getEinstellungenPanel() {
		JPanel einstellungenPanel = new JPanel();

//		Layout festlegen
		String spalten = "right:pref, 8dlu, pref";
		String zeilen = "pref";
		for (int i = 0; i < uhrzeitenViertel.length; i++) {
			zeilen += ", 4dlu:grow(0.2), pref";
		}
		FormLayout formLayout = new FormLayout(spalten, zeilen);
		einstellungenPanel.setLayout(formLayout);
		einstellungenPanel.setBorder(Borders.DIALOG_BORDER);

//		Komponenten anordnen
		CellConstraints cc = new CellConstraints();
		spinnerDauerViertel = SwingFabrik.erzeugeSpinnerZeitdauer(getDauer());
		einstellungenPanel.add(new JLabel("Dauer der Viertel"), cc.xy(1, 1));
		einstellungenPanel.add(spinnerDauerViertel, cc.xy(3, 1));
		addUhrzeitenSpinner(einstellungenPanel, cc);

		return einstellungenPanel;
	}

	private int getDauer() {
		int zeitInMinuten;
		if (uhrzeitenViertel.length > 1) {
			zeitInMinuten = DatumUtil.getMinute(uhrzeitenViertel[0][1]) - DatumUtil.getMinute(uhrzeitenViertel[0][0]);
		} else {
			zeitInMinuten = PdfErzeugerKonstanten.DEFAULT_VIERTEL_DAUER;
		}
		return DatumUtil.getUhrzeit(zeitInMinuten);
	}

	public int[][] getUhrzeitenViertel() {
		return uhrzeitenViertel;
	}

	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == buttonOk) {
			int dauer = DatumUtil.getUhrzeit((Date) spinnerDauerViertel.getValue());
			uhrzeitenViertel = new int[spinnerUhrzeitenViertel.length][2];
			for (int i = 0; i < spinnerUhrzeitenViertel.length; i++) {
				int beginnViertel = DatumUtil.getUhrzeit((Date) spinnerUhrzeitenViertel[i].getValue());
				int endeViertel = beginnViertel + dauer;
				uhrzeitenViertel[i][0] = beginnViertel;
				uhrzeitenViertel[i][1] = endeViertel;
			}
			schliesseDialog();
		} else if (e.getSource() == buttonAbbruch) {
			schliesseDialog();
		}
	}

	private void addUhrzeitenSpinner(JPanel einstellungenPanel, CellConstraints cc) {
		spinnerUhrzeitenViertel = new JSpinner[uhrzeitenViertel.length];

		for (int i = 0; i < uhrzeitenViertel.length; i++) {
			int uhrzeit = uhrzeitenViertel[i][0];
			int nummerViertel = i + 1;
			int reihe = 2 * i + 3;

			spinnerUhrzeitenViertel[i] = SwingFabrik.erzeugeSpinnerUhrzeit(uhrzeit);
			einstellungenPanel.add(new JLabel("Beginn " + nummerViertel + ". Viertel"), cc.xy(1, reihe));
			einstellungenPanel.add(spinnerUhrzeitenViertel[i], cc.xy(3, reihe));
		}
	}
}