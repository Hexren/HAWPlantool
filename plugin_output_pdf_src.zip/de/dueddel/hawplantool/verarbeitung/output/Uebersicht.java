package de.dueddel.hawplantool.verarbeitung.output;

import de.dueddel.hawplantool.HAWPlanToolException;

/**
 * <code>Uebersicht</code>
 */
public interface Uebersicht {

	public void erzeugePdf() throws HAWPlanToolException;
}