package de.dueddel.hawplantool.verarbeitung.output;

import com.lowagie.text.*;
import com.lowagie.text.Font;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import de.dueddel.hawplantool.HAWPlanToolException;
import de.dueddel.hawplantool.konstanten.TerminKonstanten;
import de.dueddel.hawplantool.util.DatumUtil;
import de.dueddel.hawplantool.verarbeitung.daten.VeranstaltungsTermin;

import java.awt.*;
import java.io.File;
import java.util.*;

/**
 * <code>WochenUebersicht</code>
 */
public class WochenUebersicht implements Uebersicht {

	private Collection<VeranstaltungsTermin> termine;
	private File ausgabeDatei;
	private Color farbeHintergrundVeranstaltung;
	private Color farbeHintergrundTag;
	private Color farbeHintergrundUhrzeit;
	private int[][] uhrzeitenViertel;
	private Collection<VeranstaltungsTermin> erfassteTermine;

	public WochenUebersicht(Collection<VeranstaltungsTermin> termine, File ausgabeDatei, int[][] uhrzeitenViertel, Color farbeHintergrundVeranstaltung, Color farbeHintergrundTag, Color farbeHintergrundUhrzeit) {
		this.termine = termine;
		this.ausgabeDatei = ausgabeDatei;
		this.farbeHintergrundVeranstaltung = farbeHintergrundVeranstaltung;
		this.farbeHintergrundTag = farbeHintergrundTag;
		this.farbeHintergrundUhrzeit = farbeHintergrundUhrzeit;
		this.uhrzeitenViertel = uhrzeitenViertel;
		erfassteTermine = new ArrayList<VeranstaltungsTermin>();
	}

	public void erzeugePdf() throws HAWPlanToolException {
		SortedMap<KW, SortedSet<VeranstaltungsTermin>> kalenderwochenTerminMap = getKalenderwochenTerminMap();

		Document document = PdfErzeugerUtil.getDocument(ausgabeDatei, PageSize.A4.rotate());

		HeaderFooter footer = new HeaderFooter(new Phrase("Seite ", PdfErzeugerKonstanten.FONT_KOMPAKTUEBERSICHT), true);
		footer.setAlignment(Element.ALIGN_RIGHT);
		footer.setBorder(0);
		document.setFooter(footer);

		document.open();

		Calendar datumMin = Calendar.getInstance();
		datumMin.setTime(kalenderwochenTerminMap.get(kalenderwochenTerminMap.firstKey()).first().getBeginn());
		Calendar datumMax = Calendar.getInstance();
		datumMax.setTime(kalenderwochenTerminMap.get(kalenderwochenTerminMap.lastKey()).last().getBeginn());

		for (KW kw : kalenderwochenTerminMap.keySet()) {
			try {
				SortedSet<VeranstaltungsTermin> termineDerKW = kalenderwochenTerminMap.get(kw);
				if (termineDerKW != null && !termineDerKW.isEmpty()) {
					document.add(getTitel(kw));
					document.add(getTabelleMitWochenuebersicht(kw, termineDerKW));
					document.newPage();
				}
			} catch (DocumentException e) {
				throw new HAWPlanToolException("Fehler beim Hinzuf�gen der Termine f�r die Kalenderwoche " + kw, e);
			}
		}

		document.close();
	}

	private Phrase getTitel(KW kalenderwoche) {
		return new Phrase("Stundenplan f�r KW " + kalenderwoche.getWoche() + " (" + kalenderwoche.getJahr() + ")", PdfErzeugerKonstanten.FONT_WOCHENUEBERSICHT_UEBERSCHRIFT);
	}

	private PdfPTable getTabelleMitWochenuebersicht(KW kalenderwoche, SortedSet<VeranstaltungsTermin> termineDerKW) throws HAWPlanToolException {
		Calendar kalenderLetzterTermin = Calendar.getInstance();
		kalenderLetzterTermin.setTime(termineDerKW.last().getBeginn());
		int tagLetzterTermin = kalenderLetzterTermin.get(Calendar.DAY_OF_WEEK);
//		wenn tagLetzterTermin=Sonntag, dann 8 Spalten, ansonsten wenn mindestens 6 Spalten
		int anzahlSpalten = tagLetzterTermin == Calendar.SUNDAY ? 8 : tagLetzterTermin < 6 ? 6 : tagLetzterTermin;

		PdfPTable tabelle = new PdfPTable(anzahlSpalten);
		initTabelleFuerWochenuebersicht(tabelle, anzahlSpalten);

//		zeilenweise �ber die Tabelle iterieren
		for (int viertel = 0; viertel <= 6; viertel++) {
//			spaltenweise �ber die Tabelle iterieren
			for (int spalte = 1; spalte <= anzahlSpalten; spalte++) {

//				wenn erste Zeile, dann Zelle mit Wochentag hinzuf�gen
				if (viertel == 0) {
					tabelle.addCell(getZelleWochentag(kalenderwoche, spalte));
				}
//				wenn erste Spalte, dann Zelle mit Information zum Viertel hinzuf�gen
				else if (spalte == 1) {
					tabelle.addCell(getZelleViertel(viertel));
				}
//				ansonsten Zelle mit Termin hinzuf�gen
				else {
					tabelle.addCell(getZelleTermin(termineDerKW, spalte, viertel));
				}
			}
		}

		return tabelle;
	}

	private void initTabelleFuerWochenuebersicht(PdfPTable tabelle, int anzahlSpalten) throws HAWPlanToolException {
		tabelle.setWidthPercentage(100);
		try {
			int[] relativeSpaltenbreiten = new int[anzahlSpalten];
			relativeSpaltenbreiten[0] = 2;
			for (int i = 1; i < anzahlSpalten; i++) {
				relativeSpaltenbreiten[i] = 5;
			}
			tabelle.setWidths(relativeSpaltenbreiten);
		} catch (DocumentException e) {
			throw new HAWPlanToolException("Fehler beim Setzen der Spaltenbreiten.", e);
		}
	}

	private PdfPCell getZelleWochentag(KW kalenderwoche, int spalte) {
//		wenn erste Spalte, dann leere Zelle
		if (spalte == 1) {
			return new PdfPCell();
		}

		Calendar kalender = kalenderwoche.getCalendar();
		kalender.set(Calendar.DAY_OF_WEEK, spalte);

		PdfPCell zelle = new PdfPCell();
		zelle.addElement(new Phrase(DatumUtil.getWochentagString(spalte == 8 ? Calendar.SUNDAY : spalte) + "\n", PdfErzeugerKonstanten.FONT_WOCHENUEBERSICHT_FETT));
		zelle.addElement(new Phrase(kalender.get(Calendar.DAY_OF_MONTH) + "." + (kalender.get(Calendar.MONTH) + 1) + "." + kalender.get(Calendar.YEAR), PdfErzeugerKonstanten.FONT_WOCHENUEBERSICHT));
		zelle.setBackgroundColor(farbeHintergrundTag);
		return zelle;
	}

	private PdfPCell getZelleViertel(int viertel) {
		PdfPCell zelle = new PdfPCell(new Phrase("(" + viertel + ")\n" + getUhrzeitViertel(viertel), PdfErzeugerKonstanten.FONT_WOCHENUEBERSICHT));
		zelle.setBackgroundColor(farbeHintergrundUhrzeit);
		zelle.setHorizontalAlignment(Element.ALIGN_CENTER);
		zelle.setVerticalAlignment(Element.ALIGN_MIDDLE);
		return zelle;
	}

	private String getUhrzeitViertel(int viertel) {
		if (viertel > uhrzeitenViertel.length) {
			return null;
		}

		int indexViertel = viertel - 1;
		return DatumUtil.getUhrzeitString(uhrzeitenViertel[indexViertel][0]) + "\n" + DatumUtil.getUhrzeitString(uhrzeitenViertel[indexViertel][1]);
	}

	private PdfPCell getZelleTermin(SortedSet<VeranstaltungsTermin> termineDerKW, int spalte, int viertel) {
		for (VeranstaltungsTermin termin : termineDerKW) {
			Calendar kalenderTermin = Calendar.getInstance();
			kalenderTermin.setTime(termin.getBeginn());

			if (kalenderTermin.get(Calendar.DAY_OF_WEEK) == spalte && isViertel(viertel, termin.getBeginn(), termin.getEnde())) {
				PdfPCell zelle = new PdfPCell();

				Font fontName = new Font(PdfErzeugerKonstanten.FONT_WOCHENUEBERSICHT_FETT);
				Font fontUhrzeit = new Font(PdfErzeugerKonstanten.FONT_WOCHENUEBERSICHT_KLEIN);
				Font fontDetails = new Font(PdfErzeugerKonstanten.FONT_WOCHENUEBERSICHT);

//				erstes Viertel der Veranstaltung
				if (!erfassteTermine.contains(termin)) {
					erfassteTermine.add(termin);
				}
//				anderes Viertel der Veranstaltung
				else {
//					fontName.setColor(farbeHintergrundVeranstaltung);
					fontUhrzeit.setColor(farbeHintergrundVeranstaltung);
					fontDetails.setColor(farbeHintergrundVeranstaltung);
				}

				zelle.addElement(new Phrase(termin.getName(), fontName));
				zelle.addElement(new Phrase(DatumUtil.getUhrzeitString(termin.getBeginn()) + "-" + DatumUtil.getUhrzeitString(termin.getEnde()), fontUhrzeit));
				zelle.addElement(new Phrase("Prof/Dozent: " + (TerminKonstanten.PROF_NICHT_ANGEGEBEN.equals(termin.getProf()) ? PdfErzeugerKonstanten.UNBEKANNT : termin.getProf()), fontDetails));
				zelle.addElement(new Phrase("Ort: " + (TerminKonstanten.ORT_NICHT_ANGEGEBEN.equals(termin.getOrt()) ? PdfErzeugerKonstanten.UNBEKANNT : termin.getOrt()), fontDetails));
				zelle.setBackgroundColor(farbeHintergrundVeranstaltung);

				return zelle;
			}
		}
		return new PdfPCell();
	}

	private boolean isViertel(int viertel, Date datumBeginn, Date datumEnde) {
		if (viertel >= uhrzeitenViertel.length) {
			return false;
		}

		int uhrzeitBeginn = DatumUtil.getUhrzeit(datumBeginn);
		int uhrzeitEnde = DatumUtil.getUhrzeit(datumEnde);
		int indexViertel = viertel - 1;

//		if (viertel == 1 || viertel == uhrzeitenViertel.length) {
//			return (uhrzeitBeginn == uhrzeitenViertel[indexViertel][0]) || (uhrzeitEnde == uhrzeitenViertel[indexViertel][1]);
//		}
		return (uhrzeitBeginn == uhrzeitenViertel[indexViertel][0]) || (uhrzeitEnde == uhrzeitenViertel[indexViertel][1]) || (uhrzeitBeginn <= uhrzeitenViertel[indexViertel][0] && uhrzeitEnde >= uhrzeitenViertel[indexViertel][1]);
	}

	private SortedMap<KW, SortedSet<VeranstaltungsTermin>> getKalenderwochenTerminMap() {
		SortedMap<KW, SortedSet<VeranstaltungsTermin>> termineInDenWochen = new TreeMap<KW, SortedSet<VeranstaltungsTermin>>();

		for (VeranstaltungsTermin termin : termine) {
			KW kalenderwoche = new KW(termin.getBeginn());

			if (!termineInDenWochen.containsKey(kalenderwoche)) {
				SortedSet<VeranstaltungsTermin> termineInEinerKW = new TreeSet<VeranstaltungsTermin>();
				termineInDenWochen.put(kalenderwoche, termineInEinerKW);
			}
			termineInDenWochen.get(kalenderwoche).add(termin);
		}

		return termineInDenWochen;
	}
}