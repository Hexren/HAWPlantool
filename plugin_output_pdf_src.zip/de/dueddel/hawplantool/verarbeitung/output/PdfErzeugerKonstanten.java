package de.dueddel.hawplantool.verarbeitung.output;

import de.dueddel.hawplantool.util.DatumUtil;

import java.awt.*;

/**
 * <code>PdfErzeugerKonstanten</code>
 */
public interface PdfErzeugerKonstanten {

	public static final Color DEFAULT_FARBE_RAHMEN_LUECKE = new Color(230, 230, 230);
	public static final Color DEFAULT_FARBE_HINTERGRUND_UHRZEIT = new Color(230, 250, 230);
	public static final Color DEFAULT_FARBE_HINTERGRUND_TAG = new Color(230, 230, 250);
	public static final Color DEFAULT_FARBE_HINTERGRUND_VERANSTALTUNG = new Color(250, 250, 230);

	public static final int SCHRIFT_FAMILIE = com.lowagie.text.Font.HELVETICA;
	public static final int SCHRIFT_GROESSE_KOMPAKTUEBERSICHT = 8;
	public static final int SCHRIFT_GROESSE_WOCHENUEBERSICHT = 11;
	public static final int SCHRIFT_GROESSE_WOCHENUEBERSICHT_KLEIN = 8;
	public static final int SCHRIFT_GROESSE_WOCHENUEBERSICHT_UEBERSCHRIFT = 15;

	public static final com.lowagie.text.Font FONT_KOMPAKTUEBERSICHT = new com.lowagie.text.Font(SCHRIFT_FAMILIE, SCHRIFT_GROESSE_KOMPAKTUEBERSICHT);
	public static final com.lowagie.text.Font FONT_KOMPAKTUEBERSICHT_FETT = new com.lowagie.text.Font(SCHRIFT_FAMILIE, SCHRIFT_GROESSE_KOMPAKTUEBERSICHT, com.lowagie.text.Font.BOLD);
	public static final com.lowagie.text.Font FONT_WOCHENUEBERSICHT = new com.lowagie.text.Font(SCHRIFT_FAMILIE, SCHRIFT_GROESSE_WOCHENUEBERSICHT);
	public static final com.lowagie.text.Font FONT_WOCHENUEBERSICHT_KLEIN = new com.lowagie.text.Font(SCHRIFT_FAMILIE, SCHRIFT_GROESSE_WOCHENUEBERSICHT_KLEIN);
	public static final com.lowagie.text.Font FONT_WOCHENUEBERSICHT_FETT = new com.lowagie.text.Font(SCHRIFT_FAMILIE, SCHRIFT_GROESSE_WOCHENUEBERSICHT, com.lowagie.text.Font.BOLD);
	public static final com.lowagie.text.Font FONT_WOCHENUEBERSICHT_UEBERSCHRIFT = new com.lowagie.text.Font(SCHRIFT_FAMILIE, SCHRIFT_GROESSE_WOCHENUEBERSICHT_UEBERSCHRIFT);

	public static final String UNBEKANNT = "???";

	public static final int DEFAULT_VIERTEL_DAUER = 90;

	public static final int DEFAULT_VIERTEL_1_VON = 815;
	public static final int DEFAULT_VIERTEL_2_VON = 1000;
	public static final int DEFAULT_VIERTEL_3_VON = 1230;
	public static final int DEFAULT_VIERTEL_4_VON = 1415;
	public static final int DEFAULT_VIERTEL_5_VON = 1615;
	public static final int DEFAULT_VIERTEL_6_VON = 1800;

	public static final int[][] DEFAULT_UHRZEITEN_VIERTEL = new int[][]{
			{DEFAULT_VIERTEL_1_VON, DEFAULT_VIERTEL_1_VON + DatumUtil.getUhrzeit(DEFAULT_VIERTEL_DAUER)},
			{DEFAULT_VIERTEL_2_VON, DEFAULT_VIERTEL_2_VON + DatumUtil.getUhrzeit(DEFAULT_VIERTEL_DAUER)},
			{DEFAULT_VIERTEL_3_VON, DEFAULT_VIERTEL_3_VON + DatumUtil.getUhrzeit(DEFAULT_VIERTEL_DAUER)},
			{DEFAULT_VIERTEL_4_VON, DEFAULT_VIERTEL_4_VON + DatumUtil.getUhrzeit(DEFAULT_VIERTEL_DAUER)},
			{DEFAULT_VIERTEL_5_VON, DEFAULT_VIERTEL_5_VON + DatumUtil.getUhrzeit(DEFAULT_VIERTEL_DAUER)},
			{DEFAULT_VIERTEL_6_VON, DEFAULT_VIERTEL_6_VON + DatumUtil.getUhrzeit(DEFAULT_VIERTEL_DAUER)}
	};
}