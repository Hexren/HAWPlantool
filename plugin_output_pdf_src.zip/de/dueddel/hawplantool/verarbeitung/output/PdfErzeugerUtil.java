package de.dueddel.hawplantool.verarbeitung.output;

import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.Rectangle;
import com.lowagie.text.pdf.PdfWriter;
import de.dueddel.hawplantool.HAWPlanToolException;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;

/**
 * <code>PdfErzeugerUtil</code>
 */
public class PdfErzeugerUtil {

	public static Document getDocument(File ausgabeDatei, Rectangle groesse) throws HAWPlanToolException {
		Document document = new Document(groesse, 20, 20, 20, 20);

		try {
			PdfWriter.getInstance(document, new FileOutputStream(ausgabeDatei));
		} catch (DocumentException e) {
			throw new HAWPlanToolException("Fehler beim Erzeugen des PdfWriters.", e);
		} catch (FileNotFoundException e) {
			throw new HAWPlanToolException("Fehler beim Erzeugen des PdfWriters.", e);
		}

		document.addTitle("HAW-Stundenplan");
		document.addCreator("HAW-Plan Tool");

		return document;
	}
}