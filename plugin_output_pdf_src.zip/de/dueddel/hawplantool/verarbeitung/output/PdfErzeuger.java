package de.dueddel.hawplantool.verarbeitung.output;

import com.jgoodies.forms.layout.CellConstraints;
import com.jgoodies.forms.layout.FormLayout;
import de.dueddel.hawplantool.HAWPlanToolException;
import de.dueddel.hawplantool.fabrik.SwingFabrik;
import de.dueddel.hawplantool.konstanten.ProgrammKonstanten;
import de.dueddel.hawplantool.verarbeitung.daten.VeranstaltungsTermin;

import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.Collection;

/**
 * <code>PdfErzeuger</code>
 */
public class PdfErzeuger extends ErgebnisErzeuger_A implements ActionListener, ChangeListener {

	private JLabel labelDatei;
	private JLabel labelUebersichtAuswahl;
	private JLabel labelEinstellungenViertel;
	private JLabel labelFarbeHintergrundUhrzeit;
	private JLabel labelFarbeHintergrundTag;
	private JLabel labelFarbeHintergrundVeranstaltung;
	private JTextField textfeldDatei;
	private JTextField textfeldFarbeHintergrundUhrzeit;
	private JTextField textfeldFarbeHintergrundTag;
	private JTextField textfeldFarbeHintergrundVeranstaltung;
	private JButton buttonDatei;
	private JButton buttonEinstellungenViertel;
	private JButton buttonFarbwahlHintergrundUhrzeit;
	private JButton buttonFarbwahlHintergrundTag;
	private JButton buttonFarbwahlHintergrundVeranstaltung;
	private JRadioButton radioButtonKompaktuerbersicht;
	private JRadioButton radioButtonWochenuebersicht;

	private File datei;
	private boolean isKompaktuebersicht;
	private int[][] uhrzeitenViertel;
	private int[][] uhrzeitenViertelTemp;
	private Color farbeHintergrundUhrzeit;
	private Color farbeHintergrundTag;
	private Color farbeHintergrundVeranstaltung;

	/**
	 * Konstruktor. Erzeugt eine Instanz der Klasse <code>PdfErzeuger</code>.
	 */
	public PdfErzeuger() {
		datei = new File(ProgrammKonstanten.PROGRAMM_VERZEICHNIS, "meinHAWPlan.pdf");
		isKompaktuebersicht = true;
		uhrzeitenViertel = PdfErzeugerKonstanten.DEFAULT_UHRZEITEN_VIERTEL;
		uhrzeitenViertelTemp = uhrzeitenViertel;
		farbeHintergrundUhrzeit = PdfErzeugerKonstanten.DEFAULT_FARBE_HINTERGRUND_UHRZEIT;
		farbeHintergrundTag = PdfErzeugerKonstanten.DEFAULT_FARBE_HINTERGRUND_TAG;
		farbeHintergrundVeranstaltung = PdfErzeugerKonstanten.DEFAULT_FARBE_HINTERGRUND_VERANSTALTUNG;

		labelDatei = new JLabel("Datei");
		labelUebersichtAuswahl = new JLabel("Art des Stundenplans");
		labelEinstellungenViertel = new JLabel("Zeiten der Veranstaltungsviertel einstellen");
		labelEinstellungenViertel.setEnabled(false);
		labelFarbeHintergrundUhrzeit = new JLabel("Hintergrundfarbe Uhrzeit");
		labelFarbeHintergrundTag = new JLabel("Hintergrundfarbe Tag");
		labelFarbeHintergrundVeranstaltung = new JLabel("Hintergrundfarbe Veranstaltung");

		textfeldDatei = new JTextField();
		textfeldDatei.setColumns(30);
		textfeldDatei.setText(datei.getAbsolutePath());

		textfeldFarbeHintergrundUhrzeit = erzeugeTextfeldFuerFarbe(farbeHintergrundUhrzeit);
		textfeldFarbeHintergrundTag = erzeugeTextfeldFuerFarbe(farbeHintergrundTag);
		textfeldFarbeHintergrundVeranstaltung = erzeugeTextfeldFuerFarbe(farbeHintergrundVeranstaltung);

		buttonDatei = SwingFabrik.erzeugeButton("...", this);
		buttonEinstellungenViertel = SwingFabrik.erzeugeButton("...", this);
		buttonEinstellungenViertel.setEnabled(false);
		buttonFarbwahlHintergrundUhrzeit = SwingFabrik.erzeugeButton("...", this);
		buttonFarbwahlHintergrundTag = SwingFabrik.erzeugeButton("...", this);
		buttonFarbwahlHintergrundVeranstaltung = SwingFabrik.erzeugeButton("...", this);

		radioButtonKompaktuerbersicht = new JRadioButton("Kompakt�bersicht (Gesamt�berblick aller KW)");
		radioButtonWochenuebersicht = new JRadioButton("Wochen�bersicht (Einzelauflistung aller KW)");
		radioButtonWochenuebersicht.addChangeListener(this);
		aktualisiereRadioButtonsUebersichtAuswahl();

		ButtonGroup buttonGroup = new ButtonGroup();
		buttonGroup.add(radioButtonWochenuebersicht);
		buttonGroup.add(radioButtonKompaktuerbersicht);
	}

	private JTextField erzeugeTextfeldFuerFarbe(Color farbe) {
		JTextField textfeld = new JTextField();
		textfeld.setColumns(20);
		textfeld.setEditable(false);
		textfeld.setEnabled(false);
		setHintergrund(textfeld, farbe);
		return textfeld;
	}

	public void erzeugeErgebnis(Collection<VeranstaltungsTermin> termine) throws HAWPlanToolException {
		Uebersicht uebersicht;
		if (isKompaktuebersicht) {
			uebersicht = new KompaktUebersicht(termine, datei, farbeHintergrundVeranstaltung, farbeHintergrundTag, farbeHintergrundUhrzeit);
		} else {
			uebersicht = new WochenUebersicht(termine, datei, uhrzeitenViertel, farbeHintergrundVeranstaltung, farbeHintergrundTag, farbeHintergrundUhrzeit);
		}
		uebersicht.erzeugePdf();
	}

	public String getKurzbeschreibung() {
		return "PDF-Datei '" + datei.getName() + "'";
	}

	public String getBeschreibung() {
		return "Erzeugt eine Datei im Portable Document Format (PDF) mit einer tabellarischen �bersicht der Veranstaltungstermine. Diese Art der �bersicht sollte bereits von den auf der HAW-Seite downloadbaren Studienpl�nen bekannt sein." +
				"\nAchtung: Die Uhrzeiten f�r die Termine werden hierbei stets auf volle " + KompaktUebersicht.GENAUIGKEIT_IN_MINUTEN + " Minuten aufgerundet." +
				"\n\nAls Alternative zu dieser kompakten Termin�bersicht ist wahlweise auch eine Einzel�bersicht aller Kalenderwochen mit den Veranstaltungsterminen m�glich. Es handelt sich im Grunde um einen ganz normalen Stundenplan, welcher auf die Darstellung der 90-min�tigen Lehreinheiten (Viertel) spezialisiert ist. Die L�nge der Viertel sowie die Uhrzeiten f�r deren Beginn k�nnen angepasst werden." +
				"\nAchtung: Terminzeiten, welche von den Zeiten der Viertel abweichen, k�nnen nicht korrekt dargestellt werden. Des Weiteren wird bei dieser Art der �bersicht davon ausgegangen, dass es keine parallel stattfindenden Veranstaltungstermine gibt. Wenn mehrere Veranstaltungen zur selben Zeit stattfinden, wird folglich nur eine davon f�r den Stundenplan verwendet." +
				"\n\nDie Hintergrundfarben der �bersichtselemente k�nnen (beispielsweise f�r den Papierdruck) ohne Weiteres angepasst werden.";
	}

	protected void initialisierePanelFuerEinstellungen(JPanel panel) {
//		Markierung des Dateipfads im Textfeld
		textfeldDatei.setSelectionStart(0);
		textfeldDatei.setSelectionEnd(datei.getAbsolutePath().length());

//		Layout festlegen
		String spalten = "right:pref, 8dlu, pref:grow, 4dlu, pref";
		String zeilen = "pref, 4dlu:grow(0.2), pref, 2dlu, pref, 2dlu, pref, 4dlu:grow(0.2), pref, 4dlu:grow(0.2), pref, 4dlu:grow(0.2), pref";
		FormLayout formLayout = new FormLayout(spalten, zeilen);
		panel.setLayout(formLayout);

//		Komponenten am Layout anordnen
		CellConstraints cc = new CellConstraints();

		panel.add(labelDatei, cc.xy(1, 1));
		panel.add(textfeldDatei, cc.xy(3, 1));
		panel.add(buttonDatei, cc.xy(5, 1));

		panel.add(labelUebersichtAuswahl, cc.xy(1, 3));
		panel.add(radioButtonKompaktuerbersicht, cc.xyw(3, 3, 2));

		panel.add(radioButtonWochenuebersicht, cc.xyw(3, 5, 2));

		panel.add(labelEinstellungenViertel, cc.xy(3, 7));
		panel.add(buttonEinstellungenViertel, cc.xy(5, 7));

		panel.add(labelFarbeHintergrundUhrzeit, cc.xy(1, 9));
		panel.add(textfeldFarbeHintergrundUhrzeit, cc.xy(3, 9));
		panel.add(buttonFarbwahlHintergrundUhrzeit, cc.xy(5, 9));

		panel.add(labelFarbeHintergrundTag, cc.xy(1, 11));
		panel.add(textfeldFarbeHintergrundTag, cc.xy(3, 11));
		panel.add(buttonFarbwahlHintergrundTag, cc.xy(5, 11));

		panel.add(labelFarbeHintergrundVeranstaltung, cc.xy(1, 13));
		panel.add(textfeldFarbeHintergrundVeranstaltung, cc.xy(3, 13));
		panel.add(buttonFarbwahlHintergrundVeranstaltung, cc.xy(5, 13));
	}

	public void aktionBeiKonfigurationOk() {
		datei = new File(textfeldDatei.getText());
		isKompaktuebersicht = radioButtonKompaktuerbersicht.isSelected();
		uhrzeitenViertel = uhrzeitenViertelTemp;
		farbeHintergrundUhrzeit = textfeldFarbeHintergrundUhrzeit.getBackground();
		farbeHintergrundTag = textfeldFarbeHintergrundTag.getBackground();
		farbeHintergrundVeranstaltung = textfeldFarbeHintergrundVeranstaltung.getBackground();
	}

	public void aktionBeiKonfigurationAbbruch() {
		textfeldDatei.setText(datei.getAbsolutePath());
		aktualisiereRadioButtonsUebersichtAuswahl();
		uhrzeitenViertelTemp = uhrzeitenViertel;
		setHintergrund(textfeldFarbeHintergrundUhrzeit, farbeHintergrundUhrzeit);
		setHintergrund(textfeldFarbeHintergrundTag, farbeHintergrundTag);
		setHintergrund(textfeldFarbeHintergrundVeranstaltung, farbeHintergrundVeranstaltung);
	}

	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == buttonDatei) {
			File zuSpeicherndeDatei = SwingFabrik.getZuSpeicherndeDatei(new File(textfeldDatei.getText()), "pdf", getOwnerFuerDialoge());
			if (zuSpeicherndeDatei != null) {
				textfeldDatei.setText(zuSpeicherndeDatei.getAbsolutePath());
			}
		} else if (e.getSource() == buttonEinstellungenViertel) {
			ViertelDialog viertelDialog = new ViertelDialog(getOwnerFuerDialoge(), uhrzeitenViertelTemp);
			uhrzeitenViertelTemp = viertelDialog.getUhrzeitenViertel();
		} else if (e.getSource() == buttonFarbwahlHintergrundUhrzeit) {
			setHintergrund(textfeldFarbeHintergrundUhrzeit, JColorChooser.showDialog(null, labelFarbeHintergrundUhrzeit.getText(), textfeldFarbeHintergrundUhrzeit.getBackground()));
		} else if (e.getSource() == buttonFarbwahlHintergrundTag) {
			setHintergrund(textfeldFarbeHintergrundTag, JColorChooser.showDialog(null, labelFarbeHintergrundTag.getText(), textfeldFarbeHintergrundTag.getBackground()));
		} else if (e.getSource() == buttonFarbwahlHintergrundVeranstaltung) {
			setHintergrund(textfeldFarbeHintergrundVeranstaltung, JColorChooser.showDialog(null, labelFarbeHintergrundVeranstaltung.getText(), textfeldFarbeHintergrundVeranstaltung.getBackground()));
		}
	}

	private void setHintergrund(JTextField textfeld, Color farbe) {
		if (farbe != null) {
			textfeld.setBackground(farbe);
			textfeld.setText("r=" + farbe.getRed() + ", g=" + farbe.getGreen() + ", b=" + farbe.getBlue());
		}
	}

	private void aktualisiereRadioButtonsUebersichtAuswahl() {
		radioButtonKompaktuerbersicht.setSelected(isKompaktuebersicht);
		radioButtonWochenuebersicht.setSelected(!isKompaktuebersicht);
	}

	public void stateChanged(ChangeEvent e) {
		if (e.getSource() == radioButtonWochenuebersicht) {
			labelEinstellungenViertel.setEnabled(radioButtonWochenuebersicht.isSelected());
			buttonEinstellungenViertel.setEnabled(radioButtonWochenuebersicht.isSelected());
		}
	}
}