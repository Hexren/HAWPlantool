package de.dueddel.hawplantool.verarbeitung.output;

import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.PageSize;
import com.lowagie.text.Phrase;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import de.dueddel.hawplantool.HAWPlanToolException;
import de.dueddel.hawplantool.util.DatumUtil;
import de.dueddel.hawplantool.util.ZahlenUtil;
import de.dueddel.hawplantool.verarbeitung.daten.VeranstaltungsTermin;

import java.awt.*;
import java.io.File;
import java.util.*;

/**
 * <code>KompaktUebersicht</code>
 */
public class KompaktUebersicht implements Uebersicht {

	/**
	 * Hilfs-Konstante. Wird f�r die (hierzulande) korrekte Einordnung von Sonntag bei der Sortierung der Wochentage verwendet.
	 * Die Integer-Konstante f�r Sonntag in der Klasse Calendar ist n�mlich kleiner als bspw. die Konstante f�r Montag.
	 *
	 * @see Calendar#SUNDAY
	 */
	private static final Integer SONNTAG = Integer.valueOf(99);
	public static final int GENAUIGKEIT_IN_MINUTEN = 5;

	private Collection<KompaktUebersichtVeranstaltung> veranstaltungen;
	private File ausgabeDatei;
	private Color farbeHintergrundVeranstaltung;
	private Color farbeHintergrundTag;
	private Color farbeHintergrundUhrzeit;

	private int ersteStunde;
	private int letzteStunde;

	public KompaktUebersicht(Collection<VeranstaltungsTermin> termine, File ausgabeDatei, Color farbeHintergrundVeranstaltung, Color farbeHintergrundTag, Color farbeHintergrundUhrzeit) {
		this.veranstaltungen = getVeranstaltungen(termine);
		this.ausgabeDatei = ausgabeDatei;
		this.farbeHintergrundVeranstaltung = farbeHintergrundVeranstaltung;
		this.farbeHintergrundTag = farbeHintergrundTag;
		this.farbeHintergrundUhrzeit = farbeHintergrundUhrzeit;
	}

	private Collection<KompaktUebersichtVeranstaltung> getVeranstaltungen(Collection<VeranstaltungsTermin> termine) {
		Map<String, KompaktUebersichtVeranstaltung> veranstaltungen = new HashMap<String, KompaktUebersichtVeranstaltung>();

//		beim Ermitteln der Veranstaltungen direkt noch den fr�hesten Beginn und das sp�teste Ende ermitteln
		if (termine != null && !termine.isEmpty()) {
			ersteStunde = getUhrzeitStundeGerundet(termine.iterator().next().getBeginn());
			letzteStunde = getUhrzeitStundeGerundet(termine.iterator().next().getEnde());
		}

		for (VeranstaltungsTermin veranstaltungsTermin : termine) {
//			erste und letzte Stunde ermitteln
			int beginnStunde = getUhrzeitStundeGerundet(veranstaltungsTermin.getBeginn());
			int endeStunde = getUhrzeitStundeGerundet(veranstaltungsTermin.getEnde());
			if (beginnStunde < ersteStunde) {
				ersteStunde = beginnStunde;
			}
			if (endeStunde > letzteStunde) {
				letzteStunde = endeStunde;
			}

			addTermin(veranstaltungen, veranstaltungsTermin);
		}

		return veranstaltungen.values();
	}

	private int getUhrzeitStundeGerundet(Date datum) {
		int uhrzeit = DatumUtil.getUhrzeit(datum);
		int uhrzeitGerundet = ZahlenUtil.rundeAuf(uhrzeit, GENAUIGKEIT_IN_MINUTEN);
		return DatumUtil.getUhrzeitStunde(uhrzeitGerundet);
	}

	private void addTermin(Map<String, KompaktUebersichtVeranstaltung> veranstaltungen, VeranstaltungsTermin termin) {
		KompaktUebersichtVeranstaltung veranstaltung = new KompaktUebersichtVeranstaltung(termin);
		if (veranstaltungen.containsKey(veranstaltung.getKey())) {
			veranstaltung = veranstaltungen.get(veranstaltung.getKey());
			veranstaltung.addTermin(termin);
		} else {
			veranstaltungen.put(veranstaltung.getKey(), veranstaltung);
		}
	}

	public void erzeugePdf() throws HAWPlanToolException {
		SortedMap<Integer, SortedSet<KompaktUebersichtVeranstaltung>> wochentagVeranstaltungenMap = getWochentagVeranstaltungenMap();

		Document document = PdfErzeugerUtil.getDocument(ausgabeDatei, PageSize.A4);
		document.open();

		try {
			document.add(getTabelleMitUebersicht(wochentagVeranstaltungenMap));
		} catch (DocumentException e) {
			throw new HAWPlanToolException("Fehler beim Hinzuf�gen der Tabelle.", e);
		}

		document.close();
	}

	private PdfPTable getTabelleMitUebersicht(SortedMap<Integer, SortedSet<KompaktUebersichtVeranstaltung>> wochentagVeranstaltungenMap) {
		PdfPTable tabelle = new PdfPTable(getSpaltenProTag());
		tabelle.setWidthPercentage(100);

		addUhrzeit(tabelle);

//		�ber die Wochentage iterieren
		for (Iterator<Integer> tagIter = wochentagVeranstaltungenMap.keySet().iterator(); tagIter.hasNext();) {
			Integer tag = tagIter.next();
			addTag(tabelle, tag);

//			die Veranstaltungen am aktuellen Wochentag
			Collection<KompaktUebersichtVeranstaltung> veranstaltungenTag = wochentagVeranstaltungenMap.get(tag);
//			Hilfs-Collection zum �berpr�fen, ob Veranstaltungen bereits in der �bersicht erfasst sind
			Collection<KompaktUebersichtVeranstaltung> bereitsErfasst = new ArrayList<KompaktUebersichtVeranstaltung>();

//			�ber die Veranstaltungen eines Tages iterieren
			for (KompaktUebersichtVeranstaltung veranstaltung : veranstaltungenTag) {
				addVeranstaltung(tabelle, veranstaltungenTag, veranstaltung, null, getNaechsteVeranstaltung(veranstaltung, veranstaltungenTag, bereitsErfasst), bereitsErfasst);
			}
		}

		addUhrzeit(tabelle);
		return tabelle;
	}

	/**
	 * Ordnet die Veranstaltungen in Collections, je eine f�r jeden Wochentag, welche widerum in einer Map gehalten werden. Die Schl�ssel der Map sind die jeweiligen Wochentage.
	 *
	 * @return SortedMap
	 */
	private SortedMap<Integer, SortedSet<KompaktUebersichtVeranstaltung>> getWochentagVeranstaltungenMap() {
		SortedMap<Integer, SortedSet<KompaktUebersichtVeranstaltung>> veranstaltungenInDerWoche = new TreeMap<Integer, SortedSet<KompaktUebersichtVeranstaltung>>();

		for (KompaktUebersichtVeranstaltung veranstaltung : veranstaltungen) {
			Integer wochentag = veranstaltung.getWochentag();

//			damit Sonntag in der Sortierung hinten landet, tempor�r den Wert verf�lschen
//			-> wird in addTag() wieder korrigiert
			if (Integer.valueOf(Calendar.SUNDAY).equals(wochentag)) {
				wochentag = SONNTAG;
			}

			if (!veranstaltungenInDerWoche.containsKey(wochentag)) {
				SortedSet<KompaktUebersichtVeranstaltung> veranstaltungenAnEinemTag = new TreeSet<KompaktUebersichtVeranstaltung>();
				veranstaltungenInDerWoche.put(wochentag, veranstaltungenAnEinemTag);
			}
			veranstaltungenInDerWoche.get(wochentag).add(veranstaltung);
		}

		return veranstaltungenInDerWoche;
	}

	private void addUhrzeit(PdfPTable tabelle) {
		for (int i = 0; i <= letzteStunde - ersteStunde; i++) {
			PdfPCell zelle = new PdfPCell();
			zelle.setUseVariableBorders(true);
			zelle.setBackgroundColor(farbeHintergrundUhrzeit);
			zelle.setColspan(getSpaltenProStunde());
			zelle.setPhrase(new Phrase((ersteStunde + i) + ":00", PdfErzeugerKonstanten.FONT_KOMPAKTUEBERSICHT));
			tabelle.addCell(zelle);
		}
	}

	private void addTag(PdfPTable tabelle, Integer tag) {
//		falls ein Sonntag dabei ist, dann wieder auf den richtigen Wert zur�ck setzen
		if (SONNTAG.equals(tag)) {
			tag = Integer.valueOf(Calendar.SUNDAY);
		}

		PdfPCell zelleVeranstaltung = new PdfPCell();
		zelleVeranstaltung.setUseVariableBorders(true);

		zelleVeranstaltung.setBackgroundColor(farbeHintergrundTag);
		zelleVeranstaltung.setColspan(getSpaltenProTag());
		zelleVeranstaltung.setPhrase(new Phrase(DatumUtil.getWochentagString(tag.intValue()), PdfErzeugerKonstanten.FONT_KOMPAKTUEBERSICHT_FETT));

		tabelle.addCell(zelleVeranstaltung);
	}

	private void addVeranstaltung(PdfPTable tabelle, Collection<KompaktUebersichtVeranstaltung> veranstaltungenTag, KompaktUebersichtVeranstaltung aktuelleVeranstaltung, KompaktUebersichtVeranstaltung vorigeVeranstaltung, KompaktUebersichtVeranstaltung naechsteVeranstaltung, Collection<KompaktUebersichtVeranstaltung> bereitsErfasst) {
//		die Veranstaltung nur hinzuf�gen, wenn noch sie noch nicht hinzugef�gt wurde
		if (!bereitsErfasst.contains(aktuelleVeranstaltung)) {

//			Tabellenzelle mit Veranstaltungsinformationen initialisieren
			PdfPCell zelleVeranstaltung = new PdfPCell();
			zelleVeranstaltung.setBackgroundColor(farbeHintergrundVeranstaltung);
			zelleVeranstaltung.setColspan(aktuelleVeranstaltung.getDauerInMinuten() / GENAUIGKEIT_IN_MINUTEN);
			zelleVeranstaltung.addElement(aktuelleVeranstaltung.getElement());

//			gibt es eine Veranstaltung vor der aktuellen?
			if (vorigeVeranstaltung != null) {
//				...dann Leerzeit von Ende der vorigen Veranstaltung bis zum aktuellen Veranstaltungsbeginn
				addLuecke(tabelle, aktuelleVeranstaltung.getBeginnMinute() - vorigeVeranstaltung.getEndeMinute(), false, false);
			} else {
//				ansonsten Leerzeit von Tagesbeginn bis Veranstaltungsbeginn
				addLuecke(tabelle, aktuelleVeranstaltung.getBeginnMinute() - getErsteMinute(), true, false);
			}

//			Zelle mit den Veranstaltungsinformationen an die Tabelle h�ngen
			tabelle.addCell(zelleVeranstaltung);
			bereitsErfasst.add(aktuelleVeranstaltung);

//			folgt auf die aktuelle Veranstaltung noch eine andere?
			if (naechsteVeranstaltung != null) {
//				...dann die n�chste Veranstaltung ranh�ngen
				addVeranstaltung(tabelle, veranstaltungenTag, naechsteVeranstaltung, aktuelleVeranstaltung, getNaechsteVeranstaltung(naechsteVeranstaltung, veranstaltungenTag, bereitsErfasst), bereitsErfasst);
			} else {
//				...ansonsten Leerzeit von Veranstaltungsende bis Tagesende
				addLuecke(tabelle, getLetzteMinute() - aktuelleVeranstaltung.getEndeMinute(), false, true);
			}
		}
	}

	private int getStundenProTag() {
		return letzteStunde + 1 - ersteStunde;
	}

	private int getMinutenProTag() {
		return getStundenProTag() * DatumUtil.FAKTOR_STUNDE;
	}

	private int getErsteMinute() {
		return DatumUtil.getMinute(ersteStunde * DatumUtil.FAKTOR_STUNDE_FUER_UHRZEIT);
	}

	private int getLetzteMinute() {
		return getErsteMinute() + getMinutenProTag();
	}

	private int getSpaltenProStunde() {
		return DatumUtil.FAKTOR_STUNDE / GENAUIGKEIT_IN_MINUTEN;
	}

	private int getSpaltenProTag() {
		return getSpaltenProStunde() * getStundenProTag();
	}

	private KompaktUebersichtVeranstaltung getNaechsteVeranstaltung(KompaktUebersichtVeranstaltung aktuelleVeranstaltung, Collection<KompaktUebersichtVeranstaltung> veranstaltungenTag, Collection<KompaktUebersichtVeranstaltung> bereitsErfasst) {
		for (KompaktUebersichtVeranstaltung naechsteVeranstaltung : veranstaltungenTag) {
			if (!bereitsErfasst.contains(naechsteVeranstaltung) && naechsteVeranstaltung.getBeginnMinute() >= aktuelleVeranstaltung.getEndeMinute()) {
				return naechsteVeranstaltung;
			}
		}
		return null;
	}

	private void addLuecke(PdfPTable tabelle, int minuten, boolean rahmenVorne, boolean rahmenHinten) {
		int anzahlZellen = minuten / GENAUIGKEIT_IN_MINUTEN;

		if (anzahlZellen == 1) {
			PdfPCell ersteZelle = getZelleLuecke(rahmenVorne, rahmenHinten);
			tabelle.addCell(ersteZelle);
		} else {
			if (anzahlZellen > 1) {
				PdfPCell ersteZelle = getZelleLuecke(rahmenVorne, false);
				tabelle.addCell(ersteZelle);
			}

			for (int i = 1; i < anzahlZellen - 1; i++) {
				PdfPCell zelle = getZelleLuecke(false, false);
				tabelle.addCell(zelle);
			}

			if (anzahlZellen > 1) {
				PdfPCell letzteZelle = getZelleLuecke(false, rahmenHinten);
				tabelle.addCell(letzteZelle);
			}
		}
	}

	private PdfPCell getZelleLuecke(boolean rahmenVorne, boolean rahmenHinten) {
		PdfPCell zelle = new PdfPCell();
		zelle.setUseVariableBorders(true);
		zelle.setBorderColor(PdfErzeugerKonstanten.DEFAULT_FARBE_RAHMEN_LUECKE);
//		nur f�r die erste Zelle der gesamten Zeile
		if (rahmenVorne) {
			zelle.setBorderColorLeft(Color.BLACK);
		}
//		nur f�r die letzte Zelle der gesamten Zeile
		if (rahmenHinten) {
			zelle.setBorderColorRight(Color.BLACK);
		}
		return zelle;
	}
}