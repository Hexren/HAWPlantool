package de.dueddel.hawplantool.verarbeitung.output;

import com.lowagie.text.Element;
import com.lowagie.text.Font;
import com.lowagie.text.Phrase;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import de.dueddel.hawplantool.konstanten.TerminKonstanten;
import de.dueddel.hawplantool.util.DatumUtil;
import de.dueddel.hawplantool.util.ZahlenUtil;
import de.dueddel.hawplantool.verarbeitung.daten.VeranstaltungsTermin;

import java.util.Calendar;
import java.util.Date;
import java.util.SortedSet;
import java.util.TreeSet;

/**
 * <code>KompaktUebersichtVeranstaltung</code>
 */
public class KompaktUebersichtVeranstaltung implements Comparable {

	private String name;
	private String prof;
	private String ort;
	private String beginnString;
	private int beginnMinute;
	private String endeString;
	private int endeMinute;
	private int wochentag;
	private String semestergruppe;
	private SortedSet<KW> kalenderwochen;

	private static final int SCHRIFT_FAMILIE = Font.HELVETICA;
	private static final int SCHRIFT_GROESSE = 8;

	private static final Font FONT_NORMAL = new Font(SCHRIFT_FAMILIE, SCHRIFT_GROESSE);
	private static final Font FONT_FETT = new Font(SCHRIFT_FAMILIE, SCHRIFT_GROESSE, Font.BOLD);

	/**
	 * Konstruktor. Erzeugt eine Instanz der Klasse <code>KompaktUebersichtVeranstaltung</code>.
	 */
	public KompaktUebersichtVeranstaltung(VeranstaltungsTermin termin) {
		kalenderwochen = new TreeSet<KW>();

		setName(termin.getName());
		setProf(termin.getProf());
		setOrt(termin.getOrt());
		setBeginn(termin.getBeginn());
		setEnde(termin.getEnde());
		setWochentag(getWochentag(termin.getBeginn()));
		setSemestergruppe(termin.getSemestergruppe());

		addTermin(termin);
	}

	public String getName() {
		return name;
	}

	private void setName(String name) {
		this.name = name;
	}

	public String getProf() {
		return prof;
	}

	private void setProf(String prof) {
		this.prof = TerminKonstanten.PROF_NICHT_ANGEGEBEN.equals(prof) ? "" : prof;
	}

	public String getOrt() {
		return ort;
	}

	private void setOrt(String ort) {
		this.ort = TerminKonstanten.ORT_NICHT_ANGEGEBEN.equals(ort) ? "" : ort;
	}

	public int getDauerInMinuten() {
		return getEndeMinute() - getBeginnMinute();
	}

	public String getBeginnString() {
		return beginnString;
	}

	private void setBeginn(Date beginn) {
		int beginnGerundet = ZahlenUtil.rundeAuf(DatumUtil.getUhrzeit(beginn), KompaktUebersicht.GENAUIGKEIT_IN_MINUTEN);
		this.beginnString = DatumUtil.getUhrzeitString(beginnGerundet);
		setBeginnMinute(DatumUtil.getMinute(beginnGerundet));
	}

	public int getBeginnMinute() {
		return beginnMinute;
	}

	private void setBeginnMinute(int beginnMinute) {
		this.beginnMinute = beginnMinute;
	}

	public String getEndeString() {
		return endeString;
	}

	private void setEnde(Date ende) {
		int endeGerundet = ZahlenUtil.rundeAuf(DatumUtil.getUhrzeit(ende), KompaktUebersicht.GENAUIGKEIT_IN_MINUTEN);
		this.endeString = DatumUtil.getUhrzeitString(endeGerundet);
		setEndeMinute(DatumUtil.getMinute(endeGerundet));
	}

	public int getEndeMinute() {
		return endeMinute;
	}

	private void setEndeMinute(int endeMinute) {
		this.endeMinute = endeMinute;
	}

	public Integer getWochentag() {
		return Integer.valueOf(wochentag);
	}

	private void setWochentag(int wochentag) {
		this.wochentag = wochentag;
	}

	private int getWochentag(Date datum) {
		Calendar datumCalendar = Calendar.getInstance();
		datumCalendar.setTime(datum);
		return datumCalendar.get(Calendar.DAY_OF_WEEK);
	}

	public String getSemestergruppe() {
		return semestergruppe;
	}

	private void setSemestergruppe(String semestergruppe) {
		this.semestergruppe = semestergruppe;
	}

	public void addTermin(VeranstaltungsTermin termin) {
		addKalenderwoche(termin.getBeginn());
	}

	public String getKalenderwochen() {
		StringBuffer kalWochen = new StringBuffer();

		KWSpanne kwSpanneTemp = new KWSpanne();
		for (KW kw : kalenderwochen) {

//			immer flei�ig die Wochen hinzuf�gen
			if (!kwSpanneTemp.add(kw)) {
//				wenn's dann einmal nicht mehr passt, dann wird die bisherige KWSpanne direkt an den StringBuffer geh�ngt
				kalWochen.append(kwSpanneTemp);
				kalWochen.append(",");

//				...und die kwSpanneTemp wird neu initialisiert und verwendet
				kwSpanneTemp = new KWSpanne();
				kwSpanneTemp.add(kw);
			}
		}
		kalWochen.append(kwSpanneTemp);

		return kalWochen.toString();
	}

	private void addKalenderwoche(Date datum) {
		KW kalenderwoche = new KW(datum);
		if (!kalenderwochen.contains(kalenderwoche)) {
			kalenderwochen.add(kalenderwoche);
		}
	}

	public String getKey() {
		StringBuffer key = new StringBuffer();
		key.append(getName());
		key.append(getSemestergruppe());
		key.append(getProf());
		key.append(getOrt());
		key.append(getWochentag());
		key.append(getBeginnString());
		key.append(getEndeString());
		return key.toString();
	}

	public int compareTo(Object o) {
		if (o instanceof KompaktUebersichtVeranstaltung) {
			KompaktUebersichtVeranstaltung v = (KompaktUebersichtVeranstaltung) o;
//			Vergleich mit Beginn
			if (!Integer.valueOf(getBeginnMinute()).equals(Integer.valueOf(v.getBeginnMinute()))) {
				return Integer.valueOf(getBeginnMinute()).compareTo(Integer.valueOf(v.getBeginnMinute()));
			}
//			Vergleich mit Namen
			if (!getName().equals(v.getName())) {
				return getName().compareTo(v.getName());
			}
//			Vergleich mit KW
			if (!getKalenderwochen().equals(v.getKalenderwochen())) {
				return getKalenderwochen().compareTo(v.getKalenderwochen());
			}
//			Vergleich mit Ort
			if (!getOrt().equals(v.getOrt())) {
				return getOrt().compareTo(v.getOrt());
			}
//			Vergleich mit Key
			return getKey().compareTo(v.getKey());
		}
		return 0;
	}

	public Element getElement() {
		PdfPTable tabelle = new PdfPTable(3);
		tabelle.setWidthPercentage(100);

		tabelle.addCell(getZelle(getBeginnString(), FONT_NORMAL, Element.ALIGN_LEFT));
		tabelle.addCell(getZelle(getProf(), FONT_FETT, Element.ALIGN_CENTER));
		tabelle.addCell(getZelle(getEndeString(), FONT_NORMAL, Element.ALIGN_RIGHT));
		tabelle.addCell(getLeerZelle());
		tabelle.addCell(getZelle(getName(), FONT_FETT, Element.ALIGN_CENTER));
		tabelle.addCell(getZelle(getOrt(), FONT_NORMAL, Element.ALIGN_RIGHT));
		tabelle.addCell(getZelle("KW " + getKalenderwochen(), FONT_NORMAL, Element.ALIGN_LEFT, 3));

		return tabelle;
	}

	private PdfPCell getLeerZelle() {
		PdfPCell zelle = new PdfPCell();
		zelle.setBorderWidth(0);
		return zelle;
	}

	private PdfPCell getZelle(String text, Font font, int ausrichtung) {
		return getZelle(text, font, ausrichtung, 1);
	}

	private PdfPCell getZelle(String text, Font font, int ausrichtung, int colspan) {
		PdfPCell zelle = new PdfPCell();
		zelle.setPhrase(new Phrase(text, font));
		zelle.setHorizontalAlignment(ausrichtung);
		zelle.setColspan(colspan);
		zelle.setBorderWidth(0);
		zelle.setNoWrap(true);
		return zelle;
	}

	private class KWSpanne {

		private SortedSet<KW> kalenderwochen;

		public KWSpanne() {
			kalenderwochen = new TreeSet<KW>();
		}

		public boolean add(KW kw) {
//			wenn SortedSet leer ist oder wenn letztes Element der Vorg�nger der �bergebenen KW
			if (kw != null && (kalenderwochen.isEmpty() || kalenderwochen.last().isDirekterVorgaengerVon(kw))) {
				kalenderwochen.add(kw);
				return true;
			}
			return false;
		}

		public String toString() {
			if (kalenderwochen.size() > 2) {
				return kalenderwochen.first().toString() + "-" + kalenderwochen.last().toString();
			}
			if (kalenderwochen.size() == 2) {
				return kalenderwochen.first().toString() + "," + kalenderwochen.last().toString();
			}
			return kalenderwochen.first().toString();
		}
	}
}