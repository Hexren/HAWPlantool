package de.dueddel.hawplantool.verarbeitung.output;

import java.util.Date;
import java.util.Calendar;

/**
 * <code>KW</code>
 */
public class KW implements Comparable {

	private Integer jahr;
	private Integer woche;

	public KW(int jahr, int woche) {
		Calendar datumCalendar = erzeugeCalendar(jahr, woche);

		jahr = Integer.valueOf(datumCalendar.get(Calendar.YEAR));
		woche = Integer.valueOf(datumCalendar.get(Calendar.WEEK_OF_YEAR));
	}

	public KW(Date datum) {
		Calendar datumCalendar = Calendar.getInstance();
		datumCalendar.setTime(datum);

		jahr = Integer.valueOf(datumCalendar.get(Calendar.YEAR));
		woche = Integer.valueOf(datumCalendar.get(Calendar.WEEK_OF_YEAR));
	}

	public int compareTo(Object o) {
		KW kw = (KW) o;
		int vergleichJahr = jahr.compareTo(kw.jahr);
		int vergleichWoche = woche.compareTo(kw.woche);

		return vergleichJahr == 0 ? vergleichWoche : vergleichJahr;
	}

	public boolean equals(Object obj) {
		KW kw = (KW) obj;
		return jahr.equals(kw.jahr) && woche.equals(kw.woche);
	}

	public boolean isDirekterVorgaengerVon(KW kw) {
		Calendar kal = erzeugeCalendar(this);
		kal.add(Calendar.WEEK_OF_YEAR, 1);
		return kal.equals(erzeugeCalendar(kw));
	}

	public String toString() {
		return woche.toString();
	}

	private Calendar erzeugeCalendar(int jahr, int woche) {
		Calendar kalenderKW = Calendar.getInstance();
		kalenderKW.setTimeInMillis(0);
		kalenderKW.set(Calendar.YEAR, jahr);
		kalenderKW.set(Calendar.WEEK_OF_YEAR, woche);
		return kalenderKW;
	}

	public Calendar erzeugeCalendar(KW kw) {
		Calendar kalenderKW = Calendar.getInstance();
		kalenderKW.setTimeInMillis(0);
		kalenderKW.set(Calendar.YEAR, kw.jahr);
		kalenderKW.set(Calendar.WEEK_OF_YEAR, kw.woche);
		return kalenderKW;
	}

	public Calendar getCalendar() {
		return erzeugeCalendar(this);
	}

	public Integer getJahr() {
		return jahr;
	}

	public void setJahr(Integer jahr) {
		this.jahr = jahr;
	}

	public Integer getWoche() {
		return woche;
	}

	public void setWoche(Integer woche) {
		this.woche = woche;
	}
}