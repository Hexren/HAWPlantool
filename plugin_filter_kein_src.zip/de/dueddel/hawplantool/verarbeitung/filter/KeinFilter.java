package de.dueddel.hawplantool.verarbeitung.filter;

import de.dueddel.hawplantool.verarbeitung.daten.VeranstaltungsTermin;

import javax.swing.*;

/**
 * <code>KeinFilter</code> l�sst alle <code>VeranstaltungsTermin</code>-Objekte "durchgehen", nichts wird gefiltert.
 */
public class KeinFilter extends VeranstaltungsTerminFilter_A {

	/**
	 * Konstruktor. Erzeugt eine Instanz der Klasse <code>KeinFilter</code>.
	 */
	public KeinFilter() {
	}

	protected void initialisierePanelFuerEinstellungen(JPanel panel) {
	}

	public String getKurzbeschreibung() {
		return "keine Filterung";
	}

	public String getBeschreibung() {
		return "Alle aus der Quelle stammenden Veranstaltungen werden ungefiltert weiter gereicht.";
	}

	public void aktionBeiKonfigurationOk() {
	}

	public void aktionBeiKonfigurationAbbruch() {
	}

	public boolean isZuFiltern(VeranstaltungsTermin termin) {
		return false;
	}
}