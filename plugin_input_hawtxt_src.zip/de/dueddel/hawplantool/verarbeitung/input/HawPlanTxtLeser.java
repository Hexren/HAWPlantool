package de.dueddel.hawplantool.verarbeitung.input;

import de.dueddel.hawplantool.HAWPlanToolException;
import de.dueddel.hawplantool.fabrik.SwingFabrik;
import de.dueddel.hawplantool.konstanten.ProgrammKonstanten;
import de.dueddel.hawplantool.verarbeitung.daten.VeranstaltungsTermin;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.Collection;

/**
 * <code>HawPlanTxtLeser</code>
 */
public class HawPlanTxtLeser extends VeranstaltungsTerminErmittler_A implements ActionListener {

	private File datei;
	private JLabel label;
	private JTextField textfeldDatei;
	private JButton buttonDatei;

	public HawPlanTxtLeser() {
		datei = ProgrammKonstanten.PROGRAMM_VERZEICHNIS;
		label = new JLabel("Datei");
		textfeldDatei = new JTextField();
		textfeldDatei.setColumns(30);
		textfeldDatei.setText(datei.getAbsolutePath());
		buttonDatei = SwingFabrik.erzeugeButton("...", this);
	}

	/**
	 * Ermittelt alle Veranstaltungen.
	 *
	 * @return <code>Collection</code> aus <code>VeranstaltungsTermin</code>-Objekten
	 * @throws de.dueddel.hawplantool.HAWPlanToolException
	 *
	 */
	public Collection<VeranstaltungsTermin> getVeranstaltungsTermineUngefiltert() throws HAWPlanToolException {
		return HawPlanTxtUtil.getTermine(datei);
	}

	public String getKurzbeschreibung() {
		return "HAW-Studienplan aus Textdatei '" + (datei.isDirectory() ? "" : datei.getName()) + "'";
	}

	public String getBeschreibung() {
		return "Ermittelt alle Veranstaltungstermine aus der Textdatei, welche die Studienpl�ne aller Semestergruppen enth�lt (Datei wird auf der HAW Seite zum Download bereit gestellt).";
	}

	protected void initialisierePanelFuerEinstellungen(JPanel panel) {
		textfeldDatei.setSelectionStart(0);
		textfeldDatei.setSelectionEnd(datei.getAbsolutePath().length());

		panel.add(label);
		panel.add(textfeldDatei);
		panel.add(buttonDatei);
	}

	public void aktionBeiKonfigurationOk() {
		datei = new File(textfeldDatei.getText());
	}

	public void aktionBeiKonfigurationAbbruch() {
		textfeldDatei.setText(datei.getAbsolutePath());
	}

	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == buttonDatei) {
			File zuLadendeDatei = SwingFabrik.getZuLadendeDatei(new File(textfeldDatei.getText()), "txt", getOwnerFuerDialoge());
			if (zuLadendeDatei != null) {
				textfeldDatei.setText(zuLadendeDatei.getAbsolutePath());
			}
		}
	}
}