package de.dueddel.hawplantool.verarbeitung.input;

import de.dueddel.hawplantool.HAWPlanToolException;
import de.dueddel.hawplantool.fabrik.ObjektFabrik;
import de.dueddel.hawplantool.konstanten.TerminKonstanten;
import de.dueddel.hawplantool.util.DateiLeser;
import de.dueddel.hawplantool.util.DatumUtil;
import de.dueddel.hawplantool.util.StringUtil;
import de.dueddel.hawplantool.verarbeitung.daten.VeranstaltungsTermin;

import java.io.File;
import java.util.*;

/**
 * <code>HawPlanTxtUtil</code>
 */
public class HawPlanTxtUtil {

	private static final String TRENNZEICHEN_DATEN = ",";
	private static final String TRENNZEICHEN_KW_LISTE = ",";
	private static final String TRENNZEICHEN_KW_SPANNE = "-";
	private static final String TRENNZEICHEN_ZEIT = ":";
	private static final String DEFAULT_KATEGORIE = "HAW";

	public static Collection<VeranstaltungsTermin> getTermine(File datei) throws HAWPlanToolException {
		Collection<VeranstaltungsTermin> termine = new ArrayList<VeranstaltungsTermin>();

		/**
		 * Bemerkung: Ein dreckiges Dateiformat erfordert dreckigen Code.
		 * Mit anderen Worten: Mir ist bewusst, dass es hier mehr oder
		 * minder Schei�e aussieht!
		 * Aber was soll man machen? Diese Textdatei der HAW ist nun mal
		 * so, wie sie ist. Naja, das Wichtigste ist ja, dass das Auslesen
		 * der Datei �berhaupt funktioniert. Auch, wenn das hier so ein
		 * Spaghetti-Code ist ...
		 * Ich habe mich immerhin bem�ht, so viel zu kommentieren, wie es
		 * n�tig ist, um hier einigerma�en durchzublicken. ;-)
		 **/

		if (datei != null) {
//			Datei mit HAW-Plan auslesen
			DateiLeser dateiLeser = ObjektFabrik.erzeugeDateiLeser(datei);
			Iterator<String> zeilenIt = dateiLeser.getZeilenIterator();

//			Semestergruppe f�r die aktuell eingelesenen Termine merken
			String semestergruppe = null;

//			�ber alle Zeilen iterieren
			while (zeilenIt.hasNext()) {
				String zeile = zeilenIt.next();

//				wenn es sich bei der aktuellen Zeile um die Angabe von Kalenderwochen handelt, ...
				if (isAngabeKW(zeile)) {
					ArrayList<Integer> kalenderwochen = getKalenderwochen(zeile);
					Collection<String> zeilenBlock = getNaechstenBlock(zeilenIt);

//					...dann �ber die angegebenen Kalenderwochen und den folgenden Block mit den Veranstaltungen iterieren
					for (Integer kw : kalenderwochen) {
						for (String zeileVeranstaltung : zeilenBlock) {

//							den Termin aus der Zeile mit den Veranstaltungs-Infos ermitteln
							VeranstaltungsTermin termin = parseZeileZuTermin(kw, zeileVeranstaltung);
							termin.setSemestergruppe(semestergruppe);
							termine.add(termin);
						}
					}
				}

//				wenn Angabe der Semestergruppe
				else if (zeile.startsWith("Semestergruppe")) {
					semestergruppe = StringUtil.getStringArray(StringUtil.getTokens(zeile, " ", false))[1];
				}
			}
		}
		return termine;
	}

	private static VeranstaltungsTermin parseZeileZuTermin(int kalenderwoche, String zeileAusBlock) throws HAWPlanToolException {
		Collection<String> veranstaltungsDaten = StringUtil.getTokens(zeileAusBlock, TRENNZEICHEN_DATEN, true);
		return erzeugeTermin(kalenderwoche, StringUtil.getStringArray(veranstaltungsDaten));
	}

	private static Collection<String> getNaechstenBlock(Iterator<String> zeilenIt) throws HAWPlanToolException {
		Collection<String> zeilenBlock = new ArrayList<String>();

		while (zeilenIt.hasNext()) {
			String zeile = zeilenIt.next();

//			wenn Kopfzeile eines Wochenblocks
			if (zeile.startsWith("Name")) {
//				dann weiter suchen
				continue;
			}

//			wenn Zeile neuen Block einleitet
			if (zeile.trim().equals("") || isEinOderKeinToken(zeile) || isAngabeKW(zeile)) {
				break;
			}

			zeilenBlock.add(zeile);
		}

		return zeilenBlock;
	}

	private static boolean isEinOderKeinToken(String zeile) {
		Collection<String> tokens = StringUtil.getTokens(zeile, TRENNZEICHEN_DATEN, false);
		return tokens == null || tokens.size() <= 1;
	}

	private static boolean isAngabeKW(String zeile) throws HAWPlanToolException {
		try {
//			lassen sich die KW ohne Fehler ermitteln?
			getKalenderwochen(zeile);
		} catch (HAWPlanToolException e) {
//			NumberFormatException ist ok, dann einfach FALSE zur�ckgeben
			if (e.getCause() instanceof NumberFormatException) {
				return false;
			}
//			wenn keine NumberFormatException, dann hochwerfen
			throw e;
		}
//		wenn keine Fehler, dann TRUE zur�ckgeben
		return true;
	}

	private static ArrayList<Integer> getKalenderwochen(String zeile) throws HAWPlanToolException {
		ArrayList<Integer> kalenderwochen = new ArrayList<Integer>();

//		Zeile untergliedern bei Auflistung von Kalenderwochen (z.B. "21, 24, 26-27" in drei Teile gliedern)
		Collection<String> kwListe = StringUtil.getTokens(zeile, TRENNZEICHEN_KW_LISTE, false);

//		�ber die Liste iterieren
		for (String kwListeToken : kwListe) {

//			Token weiter untergliedern, falls eine Zeitspanne angegeben wurde (z.B. "26-27" in zwei Teile gliedern)
			Collection<String> kwAngaben = StringUtil.getTokens(kwListeToken, TRENNZEICHEN_KW_SPANNE, false);

//			wenn Zeitspanne
			if (kwAngaben.size() == 2) {
				int kwSpanneStart;
				int kwSpanneEnde;
				try {
					Iterator<String> spanneIt = kwAngaben.iterator();
					kwSpanneStart = Integer.valueOf(spanneIt.next());
					kwSpanneEnde = Integer.valueOf(spanneIt.next());
				} catch (NumberFormatException e) {
					throw new HAWPlanToolException("Fehler beim Parsen der KW-Angabe '" + kwAngaben + "' aus der Zeile '" + zeile + "' in Integer-Werte.", e);
				}

//				die einzelnen Kalenderwochen der Zeitspanne erfassen
				for (int kw = kwSpanneStart; kw <= kwSpanneEnde; kw++) {
					kalenderwochen.add(kw);
				}
			}

//			wenn keine Zeitspanne, sondern konkrete KW-Angabe
			else {
				String kwAngabe = kwAngaben.iterator().next().trim();
				try {
//					KW-Angabe erfassen
					kalenderwochen.add(Integer.valueOf(kwAngabe));
				} catch (NumberFormatException e) {
					throw new HAWPlanToolException("Fehler beim Parsen der KW-Angabe '" + kwAngabe + "' aus der Zeile '" + zeile + "' in Integer-Werte.", e);
				}
			}
		}

		return kalenderwochen;
	}

	private static VeranstaltungsTermin erzeugeTermin(int kalenderwoche, String[] veranstaltungsDaten) throws HAWPlanToolException {
//		Prof und Raum sind unter Umst�nden nicht angegeben... deswegen hier etwas un�bersichtlicher, aber immerhin funktioniert es ;)
		int i = 0;
		String veranstaltung = veranstaltungsDaten[i];
		i += 2;
		String prof = TRENNZEICHEN_DATEN.equals(veranstaltungsDaten[i]) ? TerminKonstanten.PROF_NICHT_ANGEGEBEN : veranstaltungsDaten[i];
		i += TRENNZEICHEN_DATEN.equals(veranstaltungsDaten[i]) ? 1 : 2;
		String raum = TRENNZEICHEN_DATEN.equals(veranstaltungsDaten[i]) ? TerminKonstanten.ORT_NICHT_ANGEGEBEN : veranstaltungsDaten[i];
		i += TRENNZEICHEN_DATEN.equals(veranstaltungsDaten[i]) ? 1 : 2;
		String tag = veranstaltungsDaten[i];
		i += 2;
		Collection<String> uhrzeitBeginn = StringUtil.getTokens(veranstaltungsDaten[i], TRENNZEICHEN_ZEIT, false);
		i += 2;
		Collection<String> uhrzeitEnde = StringUtil.getTokens(veranstaltungsDaten[i], TRENNZEICHEN_ZEIT, false);

		Date beginn = getDatumUndZeit(kalenderwoche, tag, uhrzeitBeginn);
		Date ende = getDatumUndZeit(kalenderwoche, tag, uhrzeitEnde);

		VeranstaltungsTermin termin = ObjektFabrik.erzeugeVeranstaltungsTermin();
		termin.setName(veranstaltung);
		termin.setProf(prof);
		termin.setOrt(raum);
		termin.setKategorie(DEFAULT_KATEGORIE);
		termin.setBeginn(beginn);
		termin.setEnde(ende);

		return termin;
	}

	private static Date getDatumUndZeit(int kalenderwoche, String tag, Collection<String> zeit) throws HAWPlanToolException {
		if (tag == null || zeit == null) {
			throw new HAWPlanToolException("Tag oder Zeit ist NULL. " + kalenderwoche + ", tag=" + tag + ", zeit=" + zeit);
		}
		if (zeit.size() != 2) {
			String fehler = "Die Zeit hat " + zeit.size() + " Elemente, statt 2. KW=" + kalenderwoche + ", tag=" + tag + ", zeitElemente=";
			for (String zeitElement : zeit) {
				fehler += zeitElement + " ";
			}
			throw new HAWPlanToolException(fehler);
		}

		GregorianCalendar gregorianCalendar = (GregorianCalendar) GregorianCalendar.getInstance();
		gregorianCalendar.clear(GregorianCalendar.SECOND);
		gregorianCalendar.clear(GregorianCalendar.SECOND);
		gregorianCalendar.set(GregorianCalendar.WEEK_OF_YEAR, kalenderwoche);
		gregorianCalendar.set(GregorianCalendar.DAY_OF_WEEK, DatumUtil.getWochentag(tag));

		Iterator<String> zeitIt = zeit.iterator();
		String stunde = zeitIt.next();
		String minute = zeitIt.next();

		try {
			gregorianCalendar.set(GregorianCalendar.HOUR_OF_DAY, Integer.parseInt(stunde.trim()));
			gregorianCalendar.set(GregorianCalendar.MINUTE, Integer.parseInt(minute.trim()));
		} catch (NumberFormatException e) {
			throw new HAWPlanToolException("Fehler beim Parsen in einen int. KW=" + kalenderwoche + ", tag=" + tag + ", zeit=" + stunde + TRENNZEICHEN_ZEIT + minute, e);
		}

		return gregorianCalendar.getTime();
	}
}