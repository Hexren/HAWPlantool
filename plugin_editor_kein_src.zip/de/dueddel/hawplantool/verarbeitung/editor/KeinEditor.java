package de.dueddel.hawplantool.verarbeitung.editor;

import de.dueddel.hawplantool.HAWPlanToolException;
import de.dueddel.hawplantool.verarbeitung.daten.VeranstaltungsTermin;

import javax.swing.*;
import java.util.Collection;

/**
 * <code>KeinEditor</code>
 */
public class KeinEditor extends VeranstaltungsTerminEditor_A {

	/**
	 * Konstruktor. Erzeugt eine Instanz der Klasse <code>de.dueddel.hawplantool.verarbeitung.editor.KeinEditor</code>.
	 */
	public KeinEditor() {
	}

	protected void initialisierePanelFuerEinstellungen(JPanel panel) throws HAWPlanToolException {
	}

	public String getKurzbeschreibung() {
		return "keine Bearbeitung";
	}

	public String getBeschreibung() {
		return "Alle Veranstaltungen werden unbearbeitet an den Output weiter gereicht.";
	}

	public void aktionBeiKonfigurationOk() throws HAWPlanToolException {
	}

	public void aktionBeiKonfigurationAbbruch() throws HAWPlanToolException {
	}

	public Collection<VeranstaltungsTermin> bearbeiteTermine(Collection<VeranstaltungsTermin> termine) {
		return termine;
	}
}