package de.dueddel.hawplantool.verarbeitung.filter;

import de.dueddel.hawplantool.HAWPlanToolException;
import de.dueddel.hawplantool.verarbeitung.daten.VeranstaltungsTermin;
import de.dueddel.hawplantool.verarbeitung.input.VeranstaltungsTerminErmittler;

import javax.swing.*;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;

/**
 * <code>SemestergruppeFilter</code> filtert alle Veranstaltungen heraus, deren Semestergruppe nicht der Eingabe entspricht.
 */
public class SemestergruppeFilter extends VeranstaltungsTerminFilter_A {

	private String semestergruppe;

	private JLabel label;
	private JComboBox auswahlSemestergruppe;

	/**
	 * Konstruktor. Erzeugt eine Instanz der Klasse <code>SemestergruppeFilter</code>.
	 */
	public SemestergruppeFilter() {
		label = new JLabel("Semestergruppe");
		auswahlSemestergruppe = new JComboBox();
	}

	public boolean isZuFiltern(VeranstaltungsTermin termin) throws HAWPlanToolException {
		try {
			return !termin.getName().startsWith(semestergruppe);
		} catch (Exception e) {
			throw new HAWPlanToolException("Fehler beim Filtern des Termins [" + termin.toString() + "] mit der Semestergruppe '" + semestergruppe + "'.");
		}
	}

	public String getKurzbeschreibung() {
		return "Semestergruppe ist '" + semestergruppe + "'";
	}

	public String getBeschreibung() {
		return "Filtert alle Veranstaltungen heraus, die nicht zur gew�hlten Semestergruppe '" + (auswahlSemestergruppe.getSelectedItem() != null ? auswahlSemestergruppe.getSelectedItem() : semestergruppe) + "' geh�ren.";
	}

	@Override
	public void setAktuellenTerminErmittlerFuerKonfiguration(VeranstaltungsTerminErmittler terminErmittler) throws HAWPlanToolException {
		Collection<String> semesterguppen = new HashSet<String>();

		Collection<VeranstaltungsTermin> termine = terminErmittler.getVeranstaltungsTermineUngefiltert();
		for (Iterator<VeranstaltungsTermin> iterator = termine.iterator(); iterator.hasNext();) {
			VeranstaltungsTermin termin = iterator.next();
			semesterguppen.add(termin.getSemestergruppe());
		}

		String[] semesterguppenArray = new String[semesterguppen.size()];
		Iterator<String> iterator = semesterguppen.iterator();
		for (int i = 0; iterator.hasNext(); i++) {
			semesterguppenArray[i] = iterator.next();
		}
		Arrays.sort(semesterguppenArray);

		auswahlSemestergruppe.setModel(new DefaultComboBoxModel(semesterguppenArray));
		if (semestergruppe != null) {
			auswahlSemestergruppe.setSelectedItem(semestergruppe);
		} else {
			auswahlSemestergruppe.setSelectedIndex(0);
		}
	}

	protected void initialisierePanelFuerEinstellungen(JPanel panel) {
		panel.add(label);
		panel.add(auswahlSemestergruppe);
	}

	public void aktionBeiKonfigurationOk() {
		semestergruppe = (String) auswahlSemestergruppe.getSelectedItem();
	}

	public void aktionBeiKonfigurationAbbruch() {
		auswahlSemestergruppe.setSelectedItem(semestergruppe);
	}
}