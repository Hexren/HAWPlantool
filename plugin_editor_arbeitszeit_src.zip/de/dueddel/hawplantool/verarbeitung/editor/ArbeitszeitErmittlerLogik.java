package de.dueddel.hawplantool.verarbeitung.editor;

import de.dueddel.hawplantool.HAWPlanToolException;
import de.dueddel.hawplantool.fabrik.ObjektFabrik;
import de.dueddel.hawplantool.util.DatumUtil;
import de.dueddel.hawplantool.verarbeitung.daten.VeranstaltungsTermin;

import java.util.*;

/**
 * <code>ArbeitszeitErmittlerLogik</code>
 */
public class ArbeitszeitErmittlerLogik {

	private int minArbeitszeit;
	private int fahrzeit;
	private int minUhrzeit;
	private int maxUhrzeit;
	private Map<String, Boolean> wochentage;
	private TerminKonfig terminVorher;
	private TerminKonfig terminNachher;
	private TerminKonfig terminZwischendurch;
	private TerminKonfig terminGanztags;
	private boolean originaleTermineBehalten;

	private Collection<VeranstaltungsTermin> freieZeit;

	/**
	 * Konstruktor. Erzeugt eine Instanz der Klasse <code>ArbeitszeitErmittlerLogik</code>.
	 */
	public ArbeitszeitErmittlerLogik(int minArbeitszeit, int fahrzeit, int minUhrzeit, int maxUhrzeit, Map<String, Boolean> wochentage, TerminKonfig terminVorher, TerminKonfig terminNachher, TerminKonfig terminZwischendurch, TerminKonfig terminGanztags, boolean originaleTermineBehalten) {
		this.minArbeitszeit = minArbeitszeit;
		this.fahrzeit = fahrzeit;
		this.minUhrzeit = minUhrzeit;
		this.maxUhrzeit = maxUhrzeit;
		this.wochentage = wochentage;
		this.terminVorher = terminVorher;
		this.terminNachher = terminNachher;
		this.terminZwischendurch = terminZwischendurch;
		this.terminGanztags = terminGanztags;
		this.originaleTermineBehalten = originaleTermineBehalten;
	}

	public Collection<VeranstaltungsTermin> ermittlePotentielleArbeitszeit(Collection<VeranstaltungsTermin> termine) throws HAWPlanToolException {
		freieZeit = new ArrayList<VeranstaltungsTermin>();

//		in Sortierung bringen, damit zeitliche Zwischenr�ume ermittelt werden k�nnen
		SortedSet<VeranstaltungsTermin> termineSortiert = new TreeSet<VeranstaltungsTermin>(termine);

//		wenn Termine vorhanden
		if (!termineSortiert.isEmpty()) {
//			erster Termin
			pruefeZeitVorDemTermin(termineSortiert.first().getBeginn());
//			letzter Termin
			pruefeZeitNachDemTermin(termineSortiert.last().getEnde());
		}

//		�ber alle Termine iterieren
		VeranstaltungsTermin vorigerTermin = null;
		for (VeranstaltungsTermin aktuellerTermin : termineSortiert) {

//			wenn voriger Termin vorhanden
			if (vorigerTermin != null) {
				Date vorigerTerminEnde = vorigerTermin.getEnde();
				Date aktuellerTerminBeginn = aktuellerTermin.getBeginn();

//				wenn gleicher Tag
				if (DatumUtil.isGleicherTag(vorigerTerminEnde, aktuellerTerminBeginn)) {
					pruefeZeitZwischenDenTerminen(vorigerTerminEnde, aktuellerTerminBeginn);
				}

//				wenn zwei versch. Tage
				else {
					pruefeZeitNachDemTermin(vorigerTerminEnde);
					pruefeZeitVorDemTermin(aktuellerTerminBeginn);

					pruefeTageZwischenDenTerminen(vorigerTerminEnde, aktuellerTerminBeginn);
				}
			}

//			wenn allererster Termin (erster Schleifendurchlauf)
			else {
				pruefeZeitVorDemTermin(aktuellerTermin.getBeginn());
			}

			vorigerTermin = aktuellerTermin;
		}

//		Originale Termine erg�nzen, wenn gew�nscht
		if (originaleTermineBehalten) {
			freieZeit.addAll(termine);
		}

		return freieZeit;
	}

	private void pruefeTageZwischenDenTerminen(Date vorigerTerminEnde, Date aktuellerTerminBeginn) {
//		wenn beide Termine mehr als einen Tag auseinander liegen
		int differenzInTagen = DatumUtil.getAnzahlTageZwischenDenDaten(vorigerTerminEnde, aktuellerTerminBeginn);
		if (differenzInTagen > 1) {
			Calendar kalender = Calendar.getInstance();
			kalender.setTime(vorigerTerminEnde);

			for (int i = 1; i < differenzInTagen; i++) {
				kalender.add(Calendar.DATE, 1);

//				entsprechend der gew�hlten Wochentage einen neuen Termin erzeugen und hinzuf�gen
				if (isWochentagOK(kalender.getTime())) {
					freieZeit.add(erzeugeTerminTag(kalender));
				}
			}
		}
	}

	private void pruefeZeitZwischenDenTerminen(Date vorigerTerminEnde, Date aktuellerTerminBeginn) {
		int zeitZwischenDenTerminen = getZeitZwischenDenTerminen(vorigerTerminEnde, aktuellerTerminBeginn);

//		hinzuf�gen, wenn genug Zeit zwischen dem vorigen und dem aktuellen Termin und wenn Wochentag in Ordnung
		if (isZeitspanneGrossGenug(zeitZwischenDenTerminen) && isWochentagOK(aktuellerTerminBeginn)) {
			freieZeit.add(erzeugeTerminZwischendurch(vorigerTerminEnde, aktuellerTerminBeginn));
		}
	}

	private void pruefeZeitNachDemTermin(Date vorigerTerminEnde) {
		int zeitBisEnde = getZeitNachTermin(vorigerTerminEnde);

//		hinzuf�gen, wenn genug Zeit nach dem vorigen Termin und wenn Wochentag in Ordnung
		if (isZeitspanneGrossGenug(zeitBisEnde) && isWochentagOK(vorigerTerminEnde)) {
			freieZeit.add(erzeugeTerminNachher(vorigerTerminEnde));
		}
	}

	private void pruefeZeitVorDemTermin(Date aktuellerTerminBeginn) {
		int zeitBisBeginn = getZeitVorTermin(aktuellerTerminBeginn);

//		hinzuf�gen, wenn genug Zeit vor dem aktuellen Termin und wenn Wochentag in Ordnung
		if (isZeitspanneGrossGenug(zeitBisBeginn) && isWochentagOK(aktuellerTerminBeginn)) {
			freieZeit.add(erzeugeTerminVorher(aktuellerTerminBeginn));
		}
	}

	private boolean isWochentagOK(Date datum) {
		String wochentag = DatumUtil.getWochentagString(datum);
		return wochentage.get(wochentag).booleanValue();
	}

	private boolean isZeitspanneGrossGenug(int zeitZwischenDenTerminen) {
		return zeitZwischenDenTerminen >= minArbeitszeit;
	}

	private VeranstaltungsTermin erzeugeTerminVorher(Date naechsterTerminBeginn) {
		Calendar kalBeginn = Calendar.getInstance();
		kalBeginn.setTime(naechsterTerminBeginn);
		DatumUtil.setUhrzeit(kalBeginn, minUhrzeit);

		Calendar kalEnde = Calendar.getInstance();
		kalEnde.setTime(naechsterTerminBeginn);
		kalEnde.add(Calendar.MINUTE, -fahrzeit);

		return erzeugeTermin(terminVorher, kalBeginn.getTime(), kalEnde.getTime());
	}

	private VeranstaltungsTermin erzeugeTerminNachher(Date vorigerTerminEnde) {
		Calendar kalBeginn = Calendar.getInstance();
		kalBeginn.setTime(vorigerTerminEnde);
		kalBeginn.add(Calendar.MINUTE, fahrzeit);

		Calendar kalEnde = Calendar.getInstance();
		kalEnde.setTime(vorigerTerminEnde);
		DatumUtil.setUhrzeit(kalEnde, maxUhrzeit);

		return erzeugeTermin(terminNachher, kalBeginn.getTime(), kalEnde.getTime());
	}

	private VeranstaltungsTermin erzeugeTerminZwischendurch(Date vorigerTerminEnde, Date naechsterTerminBeginn) {
		Calendar kalBeginn = Calendar.getInstance();
		kalBeginn.setTime(vorigerTerminEnde);
		kalBeginn.add(Calendar.MINUTE, fahrzeit);

		Calendar kalEnde = Calendar.getInstance();
		kalEnde.setTime(naechsterTerminBeginn);
		kalEnde.add(Calendar.MINUTE, -fahrzeit);

		return erzeugeTermin(terminZwischendurch, kalBeginn.getTime(), kalEnde.getTime());
	}

	private VeranstaltungsTermin erzeugeTerminTag(Calendar kalender) {
		DatumUtil.setUhrzeit(kalender, minUhrzeit);
		Date beginn = kalender.getTime();

		DatumUtil.setUhrzeit(kalender, maxUhrzeit);
		Date ende = kalender.getTime();

		return erzeugeTermin(terminGanztags, beginn, ende);
	}

	private VeranstaltungsTermin erzeugeTermin(TerminKonfig konfig, Date beginn, Date ende) {
		VeranstaltungsTermin neuerTermin = ObjektFabrik.erzeugeVeranstaltungsTermin();
		neuerTermin.setName(konfig.getName());
		neuerTermin.setOrt(konfig.getOrt());
		neuerTermin.setKategorie(konfig.getKategorie());
		neuerTermin.setProf(konfig.getLeitung());
		neuerTermin.setSemestergruppe(konfig.getTeilnehmer());
		neuerTermin.setBeginn(beginn);
		neuerTermin.setEnde(ende);

		return neuerTermin;
	}

	private int getZeitVorTermin(Date naechsterTerminBeginn) {
		return DatumUtil.getMinute(naechsterTerminBeginn) - DatumUtil.getMinute(minUhrzeit) - fahrzeit;
	}

	private int getZeitNachTermin(Date vorigerTerminEnde) {
		return DatumUtil.getMinute(maxUhrzeit) - DatumUtil.getMinute(vorigerTerminEnde) - fahrzeit;
	}

	private int getZeitZwischenDenTerminen(Date vorigerTerminEnde, Date naechsterTerminBeginn) {
		return DatumUtil.getMinute(naechsterTerminBeginn) - DatumUtil.getMinute(vorigerTerminEnde) - 2 * fahrzeit;
	}
}