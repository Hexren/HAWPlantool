package de.dueddel.hawplantool.verarbeitung.editor;

import com.jgoodies.forms.factories.Borders;
import com.jgoodies.forms.factories.ButtonBarFactory;
import com.jgoodies.forms.layout.CellConstraints;
import com.jgoodies.forms.layout.FormLayout;
import de.dueddel.hawplantool.fabrik.SwingFabrik;
import de.dueddel.hawplantool.gui.Dialog;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * <code>TerminKonfigDialog</code>
 */
public class TerminKonfigDialog extends Dialog implements ActionListener {

	private JButton buttonOk;
	private JButton buttonAbbruch;

	private JTextField textfeldName;
	private JTextField textfeldOrt;
	private JTextField textfeldKategorie;
	private JTextField textfeldLeitung;
	private JTextField textfeldTeilnehmer;

	private TerminKonfig konfig;

	public TerminKonfigDialog(JFrame owner, TerminKonfig konfig) {
		super(owner, "Einstellungen f�r Arbeitszeittermin");

		this.konfig = new TerminKonfig();
		this.konfig.setName(konfig.getName());
		this.konfig.setOrt(konfig.getOrt());
		this.konfig.setKategorie(konfig.getKategorie());
		this.konfig.setLeitung(konfig.getLeitung());
		this.konfig.setTeilnehmer(konfig.getTeilnehmer());

		initDialog();
		zeigeDialog();
	}

	private void initDialog() {
//		Komponenten initialisieren
		buttonOk = SwingFabrik.erzeugeButton("Ok", 'o', this);
		buttonAbbruch = SwingFabrik.erzeugeButton("Abbruch", 'a', this);

		JPanel dialogPanel = new JPanel();
		JPanel einstellungenPanel = getEinstellungenPanel();
		JPanel buttonPanel = ButtonBarFactory.buildOKCancelBar(buttonOk, buttonAbbruch);

//		Layout festlegen
		String spalten = "pref:grow";
		String zeilen = "fill:pref:grow, 4dlu, pref";
		FormLayout formLayout = new FormLayout(spalten, zeilen);
		dialogPanel.setLayout(formLayout);
		dialogPanel.setBorder(Borders.DIALOG_BORDER);

//		Komponenten anordnen
		CellConstraints cc = new CellConstraints();
		dialogPanel.add(einstellungenPanel, cc.xy(1, 1));
		dialogPanel.add(buttonPanel, cc.xy(1, 3));

		getContentPane().add(dialogPanel);
		getRootPane().setDefaultButton(buttonOk);
		setResizable(true);
	}

	private JPanel getEinstellungenPanel() {
		JPanel einstellungenPanel = new JPanel();

		JLabel labelName = new JLabel("Veranstaltungsname");
		JLabel labelOrt = new JLabel("Raum/Ort");
		JLabel labelKategorie = new JLabel("Kategorie");
		JLabel labelLeitung = new JLabel("Prof/Dozent/Leitung");
		JLabel labelTeilnehmer = new JLabel("Semestergruppe/Teilnehmer");

		textfeldName = new JTextField(konfig.getName(), 15);
		textfeldOrt = new JTextField(konfig.getOrt());
		textfeldKategorie = new JTextField(konfig.getKategorie());
		textfeldLeitung = new JTextField(konfig.getLeitung());
		textfeldTeilnehmer = new JTextField(konfig.getTeilnehmer());

//		Layout festlegen
		String spalten = "right:pref, 8dlu, pref";
		String zeilen = "pref, 4dlu:grow(0.2), pref, 4dlu:grow(0.2), pref, 4dlu:grow(0.2), pref, 4dlu:grow(0.2), pref";
		FormLayout formLayout = new FormLayout(spalten, zeilen);
		einstellungenPanel.setLayout(formLayout);
		einstellungenPanel.setBorder(Borders.DIALOG_BORDER);

//		Komponenten anordnen
		CellConstraints cc = new CellConstraints();
		einstellungenPanel.add(labelName, cc.xy(1, 1));
		einstellungenPanel.add(textfeldName, cc.xy(3, 1));
		einstellungenPanel.add(labelOrt, cc.xy(1, 3));
		einstellungenPanel.add(textfeldOrt, cc.xy(3, 3));
		einstellungenPanel.add(labelKategorie, cc.xy(1, 5));
		einstellungenPanel.add(textfeldKategorie, cc.xy(3, 5));
		einstellungenPanel.add(labelLeitung, cc.xy(1, 7));
		einstellungenPanel.add(textfeldLeitung, cc.xy(3, 7));
		einstellungenPanel.add(labelTeilnehmer, cc.xy(1, 9));
		einstellungenPanel.add(textfeldTeilnehmer, cc.xy(3, 9));

		return einstellungenPanel;
	}

	public TerminKonfig getTerminKonfig() {
		return konfig;
	}

	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == buttonOk) {
			konfig.setName(textfeldName.getText());
			konfig.setOrt(textfeldOrt.getText());
			konfig.setKategorie(textfeldKategorie.getText());
			konfig.setLeitung(textfeldLeitung.getText());
			konfig.setTeilnehmer(textfeldTeilnehmer.getText());
			schliesseDialog();
		} else if (e.getSource() == buttonAbbruch) {
			schliesseDialog();
		}
	}
}