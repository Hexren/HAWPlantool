package de.dueddel.hawplantool.verarbeitung.editor;

import com.jgoodies.forms.layout.CellConstraints;
import com.jgoodies.forms.layout.FormLayout;
import de.dueddel.hawplantool.HAWPlanToolException;
import de.dueddel.hawplantool.fabrik.SwingFabrik;
import de.dueddel.hawplantool.konstanten.DatumKonstanten;
import de.dueddel.hawplantool.util.DatumUtil;
import de.dueddel.hawplantool.verarbeitung.daten.VeranstaltungsTermin;

import javax.swing.*;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

/**
 * <code>ArbeitszeitErmittler</code>
 */
public class ArbeitszeitErmittler extends VeranstaltungsTerminEditor_A implements ActionListener {

	private static final String BUTTON_TERMINDETAILS = "Termindetails bearbeiten";

	private Date arbeitszeitMin;
	private Date fahrzeitArbeitFH;
	private Date uhrzeitMin;
	private Date uhrzeitMax;
	private Map<String, Boolean> wochentage;
	private TerminKonfig terminVorher;
	private TerminKonfig terminNachher;
	private TerminKonfig terminZwischendurch;
	private TerminKonfig terminGanztags;
	private TerminKonfig terminVorherTemp;
	private TerminKonfig terminNachherTemp;
	private TerminKonfig terminZwischendurchTemp;
	private TerminKonfig terminGanztagsTemp;
	private boolean originaleTermineBehalten;

	private JLabel labelMinZeit;
	private JLabel labelReiseDauer;
	private JLabel labelMinUhrzeit;
	private JLabel labelMaxUhrzeit;
	private JLabel labelWochentage;
	private JLabel labelNameFrage;
	private JLabel labelNameVorher;
	private JLabel labelNameNachher;
	private JLabel labelNameZwischendurch;
	private JLabel labelNameGanztags;
	private JLabel labelOriginaleTermine;
	private JSpinner spinnerMinZeit;
	private JSpinner spinnerReiseDauer;
	private JSpinner spinnerMinUhrzeit;
	private JSpinner spinnerMaxUhrzeit;
	private JCheckBox checkBoxMontag;
	private JCheckBox checkBoxDienstag;
	private JCheckBox checkBoxMittwoch;
	private JCheckBox checkBoxDonnerstag;
	private JCheckBox checkBoxFreitag;
	private JCheckBox checkBoxSamstag;
	private JCheckBox checkBoxSonntag;
	private Map<String, JCheckBox> checkBoxesWochentage;
	private JButton buttonTerminVorher;
	private JButton buttonTerminNachher;
	private JButton buttonTerminZwischendurch;
	private JButton buttonTerminGanztags;
	private JCheckBox checkBoxOriginaleTermineBehalten;

	/**
	 * Konstruktor. Erzeugt eine Instanz der Klasse <code>ArbeitszeitErmittler</code>.
	 */
	public ArbeitszeitErmittler() {
		labelMinZeit = new JLabel("mindeste Arbeitszeit");
		labelReiseDauer = new JLabel("Reisedauer Arbeit\u2194FH");
		labelMinUhrzeit = new JLabel("fr�hester Arbeitsbeginn");
		labelMaxUhrzeit = new JLabel("sp�testes Arbeitsende");
		labelWochentage = new JLabel("relevante Wochentage");
		labelNameFrage = new JLabel("Wie sollen die Termine konfiguriert werden, wenn sie wie folgt stattfinden?");
		labelNameVorher = new JLabel("vor der Uni");
		labelNameNachher = new JLabel("nach der Uni");
		labelNameZwischendurch = new JLabel("zwischendurch");
		labelNameGanztags = new JLabel("ganztags");
		labelOriginaleTermine = new JLabel("Veranstaltungstermine");

		spinnerMinZeit = SwingFabrik.erzeugeSpinnerZeitdauer(330);		//	03 h 30 min
		spinnerReiseDauer = SwingFabrik.erzeugeSpinnerZeitdauer(30);	//	00 h 30 min
		spinnerMinUhrzeit = SwingFabrik.erzeugeSpinnerUhrzeit(800);		//  08:00 Uhr
		spinnerMaxUhrzeit = SwingFabrik.erzeugeSpinnerUhrzeit(1700);	//	17:00 Uhr

		checkBoxMontag = getWochentagCheckbox(DatumKonstanten.MONTAG, true);
		checkBoxDienstag = getWochentagCheckbox(DatumKonstanten.DIENSTAG, true);
		checkBoxMittwoch = getWochentagCheckbox(DatumKonstanten.MITTWOCH, true);
		checkBoxDonnerstag = getWochentagCheckbox(DatumKonstanten.DONNERSTAG, true);
		checkBoxFreitag = getWochentagCheckbox(DatumKonstanten.FREITAG, true);
		checkBoxSamstag = getWochentagCheckbox(DatumKonstanten.SAMSTAG, false);
		checkBoxSonntag = getWochentagCheckbox(DatumKonstanten.SONNTAG, false);
		wochentage = new HashMap<String, Boolean>();

		buttonTerminVorher = SwingFabrik.erzeugeButton(BUTTON_TERMINDETAILS, this);
		buttonTerminNachher = SwingFabrik.erzeugeButton(BUTTON_TERMINDETAILS, this);
		buttonTerminZwischendurch = SwingFabrik.erzeugeButton(BUTTON_TERMINDETAILS, this);
		buttonTerminGanztags = SwingFabrik.erzeugeButton(BUTTON_TERMINDETAILS, this);

		checkBoxOriginaleTermineBehalten = new JCheckBox("behalten");
		checkBoxOriginaleTermineBehalten.setSelected(false);
		checkBoxOriginaleTermineBehalten.setToolTipText("bewirkt, dass die 'originalen' Termine nicht gel�scht, sondern ebenfalls ins Ergebnis aufgenommen werden");

		terminVorherTemp = new TerminKonfig();
		terminNachherTemp = new TerminKonfig();
		terminZwischendurchTemp = new TerminKonfig();
		terminGanztagsTemp = new TerminKonfig();

		aktionBeiKonfigurationOk();	//	Aktion ausf�hren, um die Objekte zu initialisieren
	}

	private JCheckBox getWochentagCheckbox(String text, boolean checked) {
		JCheckBox checkBox = new JCheckBox(text);
		checkBox.setSelected(checked);

		if (checkBoxesWochentage == null) {
			checkBoxesWochentage = new HashMap<String, JCheckBox>();
		}
		checkBoxesWochentage.put(text, checkBox);

		return checkBox;
	}

	public String getKurzbeschreibung() {
		return "potentielle Arbeitszeiten ermitteln";
	}

	public String getBeschreibung() {
		return "In der Planung der Veranstaltungstermine entstehen so gut wie immer zeitlich ungenutzte Zwischenr�ume. Diese Leerzeiten k�nnen doch prima genutzt werden, um beispielsweise zur Arbeit zu gehen, sich einer Lerngruppe anzuschlie�en oder um ganz einfach nur zu entspannen." +
				"\n\nDieses Plugin ist in der Lage, jene Leerzeiten zwischen den Veranstaltungsterminen zu ermitteln. Somit ist eine l�ngerfristige Planung der Freizeit oder der potentiellen Arbeitszeit problemlos gew�hrt. Insbesondere Letzteres wird den einen oder anderen Chef freuen. ;-)";
	}

	protected void initialisierePanelFuerEinstellungen(JPanel panel) throws HAWPlanToolException {
//		Layout festlegen
		String spalten = "right:pref, 8dlu, pref:grow";
		String zeilen = "pref, 4dlu:grow(0.2), pref,  4dlu:grow(0.2), pref, 4dlu:grow(0.2), pref, 4dlu:grow(0.2), pref, 4dlu:grow(0.2), pref, 4dlu:grow(0.2), pref, 4dlu:grow(0.2), pref, 4dlu:grow(0.2), pref, 4dlu:grow(0.2), pref, 4dlu:grow(0.2), pref";
		FormLayout formLayout = new FormLayout(spalten, zeilen);
		panel.setLayout(formLayout);

//		Komponenten am Layout anordnen
		CellConstraints cc = new CellConstraints();

		panel.add(labelMinZeit, cc.xy(1, 1));
		panel.add(spinnerMinZeit, cc.xy(3, 1));
//		panel.add(labelEinheitMinuten, cc.xy(5, 1));

		panel.add(labelReiseDauer, cc.xy(1, 3));
		panel.add(spinnerReiseDauer, cc.xy(3, 3));

		panel.add(labelMinUhrzeit, cc.xy(1, 5));
		panel.add(spinnerMinUhrzeit, cc.xy(3, 5));

		panel.add(labelMaxUhrzeit, cc.xy(1, 7));
		panel.add(spinnerMaxUhrzeit, cc.xy(3, 7));

		panel.add(labelWochentage, cc.xy(1, 9));
		JPanel panelWochentage = new JPanel();
		panelWochentage.add(checkBoxMontag);
		panelWochentage.add(checkBoxDienstag);
		panelWochentage.add(checkBoxMittwoch);
		panelWochentage.add(checkBoxDonnerstag);
		panelWochentage.add(checkBoxFreitag);
		panelWochentage.add(checkBoxSamstag);
		panelWochentage.add(checkBoxSonntag);
		panel.add(panelWochentage, cc.xy(3, 9));

		panel.add(labelNameFrage, cc.xyw(1, 11, 3));

		panel.add(labelNameVorher, cc.xy(1, 13));
		panel.add(buttonTerminVorher, cc.xy(3, 13));

		panel.add(labelNameNachher, cc.xy(1, 15));
		panel.add(buttonTerminNachher, cc.xy(3, 15));

		panel.add(labelNameZwischendurch, cc.xy(1, 17));
		panel.add(buttonTerminZwischendurch, cc.xy(3, 17));

		panel.add(labelNameGanztags, cc.xy(1, 19));
		panel.add(buttonTerminGanztags, cc.xy(3, 19));

		panel.add(labelOriginaleTermine, cc.xy(1, 21));
		panel.add(checkBoxOriginaleTermineBehalten, cc.xy(3, 21));
	}

	public void aktionBeiKonfigurationOk() {
		arbeitszeitMin = (Date) spinnerMinZeit.getValue();
		fahrzeitArbeitFH = (Date) spinnerReiseDauer.getValue();
		uhrzeitMin = (Date) spinnerMinUhrzeit.getValue();
		uhrzeitMax = (Date) spinnerMaxUhrzeit.getValue();

		for (String tag : checkBoxesWochentage.keySet()) {
			wochentage.put(tag, Boolean.valueOf(checkBoxesWochentage.get(tag).isSelected()));
		}

		terminVorher = terminVorherTemp;
		terminNachher = terminNachherTemp;
		terminZwischendurch = terminZwischendurchTemp;
		terminGanztags = terminGanztagsTemp;

		originaleTermineBehalten = checkBoxOriginaleTermineBehalten.isSelected();
	}

	public void aktionBeiKonfigurationAbbruch() {
		spinnerMinZeit.setValue(arbeitszeitMin);
		spinnerReiseDauer.setValue(fahrzeitArbeitFH);
		spinnerMinUhrzeit.setValue(uhrzeitMin);
		spinnerMaxUhrzeit.setValue(uhrzeitMax);

		for (String tag : wochentage.keySet()) {
			checkBoxesWochentage.get(tag).setSelected(wochentage.get(tag).booleanValue());
		}

		terminVorherTemp = terminVorher;
		terminNachherTemp = terminNachher;
		terminZwischendurchTemp = terminZwischendurch;
		terminGanztagsTemp = terminGanztags;
	}

	public Collection<VeranstaltungsTermin> bearbeiteTermine(Collection<VeranstaltungsTermin> termine) throws HAWPlanToolException {
		int arbeitszeit = DatumUtil.getMinute(arbeitszeitMin);
		int fahrzeit = DatumUtil.getMinute(fahrzeitArbeitFH);
		int minUhrzeit = DatumUtil.getUhrzeit(uhrzeitMin);
		int maxUhrzeit = DatumUtil.getUhrzeit(uhrzeitMax);

		ArbeitszeitErmittlerLogik logik = new ArbeitszeitErmittlerLogik(arbeitszeit, fahrzeit, minUhrzeit, maxUhrzeit, wochentage, terminVorher, terminNachher, terminZwischendurch, terminGanztags, originaleTermineBehalten);
		return logik.ermittlePotentielleArbeitszeit(termine);
	}

	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == buttonTerminVorher) {
			terminVorherTemp = new TerminKonfigDialog(getOwnerFuerDialoge(), terminVorherTemp).getTerminKonfig();
		} else if (e.getSource() == buttonTerminNachher) {
			terminNachherTemp = new TerminKonfigDialog(getOwnerFuerDialoge(), terminNachherTemp).getTerminKonfig();
		} else if (e.getSource() == buttonTerminZwischendurch) {
			terminZwischendurchTemp = new TerminKonfigDialog(getOwnerFuerDialoge(), terminZwischendurchTemp).getTerminKonfig();
		} else if (e.getSource() == buttonTerminGanztags) {
			terminGanztagsTemp = new TerminKonfigDialog(getOwnerFuerDialoge(), terminGanztagsTemp).getTerminKonfig();
		}
	}
}