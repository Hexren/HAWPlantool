package de.dueddel.hawplantool.verarbeitung.editor;

/**
 * <code>TerminKonfig</code>
 */
public class TerminKonfig {

	private String name;
	private String kategorie;
	private String ort;
	private String leitung;
	private String teilnehmer;

	public TerminKonfig() {
		setName("Arbeit");
		setKategorie("Arbeit");
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getKategorie() {
		return kategorie;
	}

	public void setKategorie(String kategorie) {
		this.kategorie = kategorie;
	}

	public String getOrt() {
		return ort;
	}

	public void setOrt(String ort) {
		this.ort = ort;
	}

	public String getLeitung() {
		return leitung;
	}

	public void setLeitung(String leitung) {
		this.leitung = leitung;
	}

	public String getTeilnehmer() {
		return teilnehmer;
	}

	public void setTeilnehmer(String teilnehmer) {
		this.teilnehmer = teilnehmer;
	}
}