package de.dueddel.hawplantool.verarbeitung.output;

import de.dueddel.hawplantool.HAWPlanToolException;
import de.dueddel.hawplantool.fabrik.SwingFabrik;
import de.dueddel.hawplantool.konstanten.ProgrammKonstanten;
import de.dueddel.hawplantool.verarbeitung.ICalUtil;
import de.dueddel.hawplantool.verarbeitung.daten.VeranstaltungsTermin;
import net.fortuna.ical4j.model.Calendar;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.Collection;
import java.util.Iterator;

/**
 * <code>ICalErzeuger</code>
 */
public class ICalErzeuger extends ErgebnisErzeuger_A implements ActionListener {

	private File datei;
	private JLabel labelDatei;
	private JTextField textfeldDatei;
	private JButton buttonDatei;

	/**
	 * Konstruktor. Erzeugt eine Instanz der Klasse <code>ICalErzeuger</code>.
	 */
	public ICalErzeuger() {
		datei = new File(ProgrammKonstanten.PROGRAMM_VERZEICHNIS, "meinHAWPlan.ics");
		labelDatei = new JLabel("Datei");
		textfeldDatei = new JTextField();
		textfeldDatei.setColumns(30);
		textfeldDatei.setText(datei.getAbsolutePath());
		buttonDatei = SwingFabrik.erzeugeButton("...", this);
	}

	public void erzeugeErgebnis(Collection<VeranstaltungsTermin> termine) throws HAWPlanToolException {
//		Kalender erzeugen
		Calendar calendar = ICalUtil.erzeugeICalKalender();

//		Termine anh�ngen
		for (Iterator<VeranstaltungsTermin> termineIt = termine.iterator(); termineIt.hasNext();) {
			VeranstaltungsTermin termin = termineIt.next();
			calendar.getComponents().add(ICalUtil.erzeugeICalTermin(termin));
		}

//		Datei schreiben
		ICalUtil.schreibeICalDatei(calendar, datei);
	}

	public String getKurzbeschreibung() {
		return "ICalendar-Datei '" + datei.getName() + "'";
	}

	public String getBeschreibung() {
		return "Erzeugt eine Kalenderdatei im ICalendar-Format (.ics).\n\nDie erzeugte Datei kann von Programmen wie dem Sunbird-Kalender von Mozilla importiert werden.";
	}

	protected void initialisierePanelFuerEinstellungen(JPanel panel) {
		textfeldDatei.setSelectionStart(0);
		textfeldDatei.setSelectionEnd(datei.getAbsolutePath().length());

		panel.add(labelDatei);
		panel.add(textfeldDatei);
		panel.add(buttonDatei);
	}

	public void aktionBeiKonfigurationOk() {
		datei = new File(textfeldDatei.getText());
	}

	public void aktionBeiKonfigurationAbbruch() {
		textfeldDatei.setText(datei.getAbsolutePath());
	}

	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == buttonDatei) {
			File zuSpeicherndeDatei = SwingFabrik.getZuSpeicherndeDatei(new File(textfeldDatei.getText()), "ics", getOwnerFuerDialoge());
			if (zuSpeicherndeDatei != null) {
				textfeldDatei.setText(zuSpeicherndeDatei.getAbsolutePath());
			}
		}
	}
}