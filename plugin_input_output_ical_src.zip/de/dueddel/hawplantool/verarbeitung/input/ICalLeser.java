package de.dueddel.hawplantool.verarbeitung.input;

import de.dueddel.hawplantool.HAWPlanToolException;
import de.dueddel.hawplantool.fabrik.SwingFabrik;
import de.dueddel.hawplantool.konstanten.ProgrammKonstanten;
import de.dueddel.hawplantool.verarbeitung.ICalUtil;
import de.dueddel.hawplantool.verarbeitung.daten.VeranstaltungsTermin;
import net.fortuna.ical4j.model.Calendar;
import net.fortuna.ical4j.model.component.VEvent;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

/**
 * <code>ICalLeser</code>
 */
public class ICalLeser extends VeranstaltungsTerminErmittler_A implements ActionListener {

	private File datei;
	private JLabel labelDatei;
	private JTextField textfeldDatei;
	private JButton buttonDatei;

	/**
	 * Konstruktor. Erzeugt eine Instanz der Klasse <code>ICalLeser</code>.
	 */
	public ICalLeser() {
		datei = ProgrammKonstanten.PROGRAMM_VERZEICHNIS;
		labelDatei = new JLabel("Datei");
		textfeldDatei = new JTextField();
		textfeldDatei.setColumns(30);
		textfeldDatei.setText(datei.getAbsolutePath());
		buttonDatei = SwingFabrik.erzeugeButton("...", this);
	}

	/**
	 * Ermittelt alle Veranstaltungen.
	 *
	 * @return <code>Collection</code> aus <code>VeranstaltungsTermin</code>-Objekten
	 * @throws de.dueddel.hawplantool.HAWPlanToolException
	 *
	 */
	public Collection<VeranstaltungsTermin> getVeranstaltungsTermineUngefiltert() throws HAWPlanToolException {
		Collection<VeranstaltungsTermin> termine = new ArrayList<VeranstaltungsTermin>();

//		Kalender lesen
		Calendar calendar = ICalUtil.liesICalKalender(datei);

//		Termine ermitteln
		for (Iterator i = calendar.getComponents().iterator(); i.hasNext();) {
			Object component = i.next();

//			kann derzeit nur VEvent-Objekte lesen
			if (component instanceof VEvent) {
				VEvent event = (VEvent) component;

//				m�glicherweise ist f�r den Termin noch eine Wiederholungsregel definiert
				if (ICalUtil.isMitWiederholungen(event)) {
					termine.addAll(ICalUtil.getWiederholungstermine(event));
				} else {
					termine.add(ICalUtil.erzeugeVeranstaltungsTermin(event));
				}
			}
		}

//		Termine zur�ckgeben
		return termine;
	}

	public String getKurzbeschreibung() {
		return "ICalendar-Datei '" + (datei.isDirectory() ? "" : datei.getName()) + "'";
	}

	public String getBeschreibung() {
		return "Ermittelt alle Veranstaltungstermine aus einer ICalendar-Datei.\n\nAchtung: Die Termine m�ssen als VEvent gekennzeichnet sein.";
	}

	protected void initialisierePanelFuerEinstellungen(JPanel panel) {
		textfeldDatei.setSelectionStart(0);
		textfeldDatei.setSelectionEnd(datei.getAbsolutePath().length());

		panel.add(labelDatei);
		panel.add(textfeldDatei);
		panel.add(buttonDatei);
	}

	public void aktionBeiKonfigurationOk() {
		datei = new File(textfeldDatei.getText());
	}

	public void aktionBeiKonfigurationAbbruch() {
		textfeldDatei.setText(datei.getAbsolutePath());
	}

	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == buttonDatei) {
			File zuLadendeDatei = SwingFabrik.getZuLadendeDatei(new File(textfeldDatei.getText()), "ics", getOwnerFuerDialoge());
			if (zuLadendeDatei != null) {
				textfeldDatei.setText(zuLadendeDatei.getAbsolutePath());
			}
		}
	}
}