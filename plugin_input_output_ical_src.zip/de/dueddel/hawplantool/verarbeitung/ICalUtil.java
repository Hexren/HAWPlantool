package de.dueddel.hawplantool.verarbeitung;

import de.dueddel.hawplantool.HAWPlanToolException;
import de.dueddel.hawplantool.util.DatumUtil;
import de.dueddel.hawplantool.util.StringUtil;
import de.dueddel.hawplantool.fabrik.ObjektFabrik;
import de.dueddel.hawplantool.konstanten.TerminKonstanten;
import de.dueddel.hawplantool.verarbeitung.daten.VeranstaltungsTermin;
import net.fortuna.ical4j.data.CalendarBuilder;
import net.fortuna.ical4j.data.CalendarOutputter;
import net.fortuna.ical4j.data.ParserException;
import net.fortuna.ical4j.model.*;
import net.fortuna.ical4j.model.component.VEvent;
import net.fortuna.ical4j.model.parameter.Cn;
import net.fortuna.ical4j.model.parameter.Role;
import net.fortuna.ical4j.model.parameter.Value;
import net.fortuna.ical4j.model.property.*;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URISyntaxException;
import java.util.Collection;
import java.util.ArrayList;

/**
 * <code>ICalUtil</code> ist eine kleine Hilfsklasse f�r die Erzeugung von ICalendar-Dateien.
 */
public class ICalUtil {

	private static final String TEILNEHMER_PROF = "OWNER";
	private static final String TEILNEHMER_SEMESTERGRUPPE = "ATTENDEE";

	/**
	 * Erzeugt eine neue <code>Calendar</code>-Instanz.
	 *
	 * @return Calendar
	 */
	public static Calendar erzeugeICalKalender() {
		Calendar calendar = new Calendar();

		calendar.getProperties().add(new ProdId("http://hawplantool.dueddel.de"));
		calendar.getProperties().add(Version.VERSION_2_0);
		calendar.getProperties().add(CalScale.GREGORIAN);
		calendar.getProperties().add(Method.PUBLISH);

		return calendar;
	}

	/**
	 * Liest eine ICalender-Datei ein und gibt die entsprechende <code>Calendar</code>-Instanz zur�ck.
	 *
	 * @param datei
	 * @return
	 * @throws HAWPlanToolException
	 */
	public static Calendar liesICalKalender(File datei) throws HAWPlanToolException {
		try {
			FileInputStream fileIn = new FileInputStream(datei);
			CalendarBuilder builder = new CalendarBuilder();
			return builder.build(fileIn);
		} catch (IOException e) {
			throw new HAWPlanToolException("Fehler beim Einlesen der ICS-Datei.", e);
		} catch (ParserException e) {
			throw new HAWPlanToolException("Fehler beim Parsen der ICS-Datei.", e);
		}
	}

	/**
	 * Erzeugt eine ICS-Datei und speichert sie mit allen dem �bergebenen <code>Calendar</code>-Objekt enthaltenen Terminen ab.
	 *
	 * @param calendar
	 * @param datei
	 * @throws HAWPlanToolException
	 */
	public static void schreibeICalDatei(Calendar calendar, File datei) throws HAWPlanToolException {
		try {
			FileOutputStream fileOut = new FileOutputStream(datei);
			CalendarOutputter outputter = new CalendarOutputter();
			outputter.output(calendar, fileOut);
		} catch (IOException e) {
			throw new HAWPlanToolException("I/O-Fehler beim Speichern der Datei '" + datei.getAbsolutePath() + "'.", e);
		} catch (ValidationException e) {
			throw new HAWPlanToolException("Fehler beim Validieren des Kalenders.", e);
		}
	}

	/**
	 * Erzeugt ein neues <code>VEvent</code>-Objekt und bef�llt es mit den Daten des <code>VeranstaltungsTermin</code>-Objektes.
	 *
	 * @param veranstaltungsTermin
	 * @return VEvent
	 */
	public static VEvent erzeugeICalTermin(VeranstaltungsTermin veranstaltungsTermin) throws HAWPlanToolException {
		VEvent event = null;

		if (veranstaltungsTermin != null) {
			Property uid = new Uid(veranstaltungsTermin.getUid());
			Property name = new Summary(veranstaltungsTermin.getName());
			Property kategorie = StringUtil.isStringNichtLeer(veranstaltungsTermin.getKategorie()) ? new Categories(veranstaltungsTermin.getKategorie()) : null;
			Property ort = StringUtil.isStringNichtLeer(veranstaltungsTermin.getOrt()) ? new Location(veranstaltungsTermin.getOrt()) : null;
			Property prof = getPropertyTeilnehmer(veranstaltungsTermin.getProf(), TEILNEHMER_PROF);
			Property semestergruppe = getPropertyTeilnehmer(veranstaltungsTermin.getSemestergruppe(), TEILNEHMER_SEMESTERGRUPPE);
			Property beginn = getPropertyZeit(new DateTime(veranstaltungsTermin.getBeginn()), true);
			Property ende = getPropertyZeit(new DateTime(veranstaltungsTermin.getEnde()), false);
			Property beschreibung = new Description("Professor/Dozent: " + veranstaltungsTermin.getProf() + "\n" + "Raum/Ort: " + veranstaltungsTermin.getOrt());

			event = new VEvent();
			event.getProperties().add(uid);
			event.getProperties().add(name);
			if (kategorie != null) {
				event.getProperties().add(kategorie);
			}
			if (ort != null) {
				event.getProperties().add(ort);
			}
			if (prof != null) {
				event.getProperties().add(prof);
			}
			if (semestergruppe != null) {
				event.getProperties().add(semestergruppe);
			}
			event.getProperties().add(beginn);
			event.getProperties().add(ende);
			event.getProperties().add(beschreibung);
		}

		return event;
	}

	private static Property getPropertyTeilnehmer(String name, String rolleTeilnehmer) throws HAWPlanToolException {
		if (StringUtil.isStringNichtLeer(name)) {
			ParameterList profParameterList = new ParameterList();
			profParameterList.add(new Cn(name));
			profParameterList.add(new Role(rolleTeilnehmer));

			try {
				return new Attendee(profParameterList, rolleTeilnehmer);
			} catch (URISyntaxException e) {
				throw new HAWPlanToolException("Fehler beim Erzeugen eines Teilnehmer-Properties. Name=" + name + ", Rolle=" + rolleTeilnehmer, e);
			}
		}
		return null;
	}

	private static Property getPropertyZeit(Date zeit, boolean isStart) {
		ParameterList zeitParameterList = new ParameterList();
		zeitParameterList.add(Value.DATE_TIME);

		if (isStart) {
			return new DtStart(zeitParameterList, zeit);
		}
		return new DtEnd(zeitParameterList, zeit);
	}

	public static VeranstaltungsTermin erzeugeVeranstaltungsTermin(VEvent event) {
		VeranstaltungsTermin termin = ObjektFabrik.erzeugeVeranstaltungsTermin();

		Property name = event.getSummary();
		Property ort = event.getLocation();
		String prof = getNameTeilnehmer(event, TEILNEHMER_PROF);
		String semestergruppe = getNameTeilnehmer(event, TEILNEHMER_SEMESTERGRUPPE);
		Property kategorie = event.getProperty(Property.CATEGORIES);
		DateProperty beginn = event.getStartDate();
		DateProperty ende = event.getEndDate();

		termin.setName(name != null ? name.getValue() : TerminKonstanten.NAME_NICHT_ANGEGEBEN);
		termin.setOrt(ort != null ? ort.getValue() : TerminKonstanten.ORT_NICHT_ANGEGEBEN);
		termin.setProf(prof != null ? prof : TerminKonstanten.PROF_NICHT_ANGEGEBEN);
		termin.setSemestergruppe(semestergruppe);
		termin.setKategorie(kategorie != null ? kategorie.getValue() : null);
		termin.setBeginn(beginn != null ? beginn.getDate() : TerminKonstanten.DATUM_DEFAULT);
		termin.setEnde(ende != null ? ende.getDate() : TerminKonstanten.DATUM_DEFAULT);

		return termin;
	}

	private static String getNameTeilnehmer(VEvent event, String rolleTeilnehmer) {
		PropertyList teilnehmerPropertyList = event.getProperties(Property.ATTENDEE);

		for (Object teilnehmerObject : teilnehmerPropertyList) {
			Attendee teilnehmer = (Attendee) teilnehmerObject;
			Parameter nameTemp = teilnehmer.getParameter(Parameter.CN);
			Parameter rolleTemp = teilnehmer.getParameter(Parameter.ROLE);
			if (rolleTeilnehmer.equals(rolleTemp.getValue())) {
				return nameTemp.getValue();
			}
		}

		return null;
	}

	public static boolean isMitWiederholungen(VEvent event) {
		return event.getProperty(Property.RRULE) != null;
	}

	public static Collection<VeranstaltungsTermin> getWiederholungstermine(VEvent event) {
		Collection<VeranstaltungsTermin> termine = new ArrayList<VeranstaltungsTermin>();

		if (isMitWiederholungen(event)) {
			RRule wiederholungProperty = (RRule) event.getProperty(Property.RRULE);
			Recur wiederholungBeschreibung = wiederholungProperty.getRecur();

			Date beginnErsterTermin = event.getStartDate().getDate();
			Date datumMax = wiederholungBeschreibung.getUntil() != null ? wiederholungBeschreibung.getUntil() : getAlternativesUntilDatum(beginnErsterTermin);
			Date endeErsterTermin = event.getEndDate().getDate();
			int uhrzeitEndeErsterTermin = DatumUtil.getUhrzeit(endeErsterTermin);

			DateList wiederholungen = wiederholungBeschreibung.getDates(beginnErsterTermin, datumMax, Value.DATE_TIME);

			for (Object o : wiederholungen) {
				Date beginn = (Date) o;

				java.util.Calendar endeKalender = java.util.Calendar.getInstance();
				endeKalender.setTime(beginn);
				DatumUtil.setUhrzeit(endeKalender, uhrzeitEndeErsterTermin);

				VeranstaltungsTermin termin = erzeugeVeranstaltungsTermin(event);
				termin.setBeginn(beginn);
				termin.setEnde(endeKalender.getTime());

				termine.add(termin);
			}
		}

		return termine;
	}

	private static Date getAlternativesUntilDatum(Date beginnErsterTermin) {
		java.util.Calendar kalender = java.util.Calendar.getInstance();
		kalender.setTime(beginnErsterTermin);
		kalender.add(java.util.Calendar.YEAR, 2);	//	2 Jahre aufaddieren sollte wohl gen�gen

		Date datum = new Date();
		datum.setTime(kalender.getTimeInMillis());
		return datum;
	}
}